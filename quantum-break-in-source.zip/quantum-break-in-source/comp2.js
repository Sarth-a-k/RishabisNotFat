
/* Level 3: laser mazes (two or four corridors) */
COMP.maze = (st, tl, s, ctx) => {
  const n = s.paths, ph = Array(n).fill(0), c = mkCanvas(540, n === 2 ? 190 : 250), PW = PhasorW(), info = el('div', { cls: 'note' }); let ti = 0, sel = 0, tasks = s.tasks, M;
  if (s.boss) { const o = [0, 1, 2, 3]; for (let i = 3; i > 0; i--) { const j = ctx.rng.int(i + 1);[o[i], o[j]] = [o[j], o[i]]; } tasks = o.map((j, i) => ({ only: j, text: 'Guard shift ' + (i + 1) + ' of 4: The professor moved the SAFE detector.' })); }
  const safe = () => { const t = tasks[ti] || {}; return s.hide ? -1 : t.only != null ? t.only : -1; };
  const good = t => t.only != null ? M.p[t.only] >= CONFIG.tol.det : Math.abs(M.p[t.det] * 100 - t.pct) <= CONFIG.tol.dim;
  const draw = () => { const x = c.x, H = c.H, ys = Array.from({ length: n }, (_, k) => 40 + k * (H - 80) / (n - 1)), yd = Array.from({ length: n }, (_, k) => 30 + k * (H - 60) / (n - 1)); x.clearRect(0, 0, 540, H); x.font = '12px system-ui'; x.textAlign = 'center';
    x.strokeStyle = P.cyan; x.lineWidth = 4; x.beginPath(); x.moveTo(10, H / 2); x.lineTo(70, H / 2); x.stroke(); x.fillStyle = P.dim; x.fillText('laser', 30, H / 2 - 10);
    ys.forEach((y, k) => { x.strokeStyle = 'rgba(94,246,255,.75)'; x.lineWidth = 3; x.beginPath(); x.moveTo(70, H / 2); x.lineTo(130, y); x.lineTo(330, y); x.lineTo(390, H / 2); x.stroke();
      if (n === 4 || k === 1) { x.fillStyle = '#24123a'; x.strokeStyle = P.amber; x.lineWidth = 1.5; x.fillRect(205, y - 13, 60, 26); x.strokeRect(205, y - 13, 60, 26); x.fillStyle = '#fff'; x.fillText(Math.round(ph[k] * 180 / Math.PI) + '°', 235, y + 4); } });
    for (const X of [70, 390]) { x.save(); x.translate(X, H / 2); x.rotate(Math.PI / 4); x.fillStyle = '#24123a'; x.strokeStyle = '#cdb8e8'; x.fillRect(-11, -11, 22, 22); x.strokeRect(-11, -11, 22, 22); x.restore(); }
    x.fillStyle = P.dim; x.fillText('splitter', 70, H / 2 + 30); x.fillText('splitter', 390, H / 2 + 30);
    yd.forEach((y, j) => { const p = M.p[j], sf = safe() === j, al = safe() >= 0 && !sf; x.strokeStyle = 'rgba(94,246,255,' + (0.08 + 0.92 * p) + ')'; x.lineWidth = 1 + 7 * p; x.beginPath(); x.moveTo(390, H / 2); x.lineTo(430, y); x.stroke();
      x.beginPath(); x.arc(444, y, 13, 0, TAU); x.fillStyle = sf ? P.good : al ? P.bad : '#cdb8e8'; x.globalAlpha = 0.25 + 0.75 * p; x.fill(); x.globalAlpha = 1; x.strokeStyle = j === sel ? '#fff' : '#45285f'; x.lineWidth = j === sel ? 2.5 : 1; x.stroke();
      x.fillStyle = P.text; x.textAlign = 'left'; x.fillText('D' + j + ' ' + pct(p), 462, y - 2); x.fillStyle = sf ? P.good : al ? P.bad : P.dim; x.fillText(sf ? 'SAFE ✓' : al ? 'ALARM !' : '', 462, y + 12); x.textAlign = 'center'; });
    if (safe() >= 0 && M.p.some((p, j) => j !== safe() && p > 0.5)) { x.fillStyle = P.bad; x.beginPath(); x.arc(300, 12, 7, 0, TAU); x.fill(); x.textAlign = 'left'; x.fillText('Alarm would trip', 312, 16); } };
  const upd = end => { M = maze(ph); draw(); PW.draw(M.arrows(sel), 'D' + sel); const t = tasks[ti];
    info.innerHTML = M.p.map((p, j) => 'D' + j + ' <b>' + pct(p) + '</b>').join(' · '); ctx.math(n === 2 ? 'P(D1) = sin²(φ/2) = ' + (Math.sin(ph[1] / 2) ** 2).toFixed(3) : 'amplitude at D' + sel + ' = ¼ Σ ±e^{iφk} = ' + M.arrows(sel).reduce((a, b) => [a[0] + b[0], a[1] + b[1]], [0, 0]).map(v => v.toFixed(2)).join(' + i·'));
    if (end && t) { ctx.move(); if (good(t)) { ti++; if (ti >= tasks.length) return ctx.solve(); ctx.fb('Door open. Next.', true); setTask(); } else if (s.hide && M.p.some(p => p >= CONFIG.tol.det)) ctx.fb('That detector is fully lit, but it is not the SAFE one. Check the first two digits of the code.'); } };
  const setTask = () => { const t = tasks[ti]; ctx.task(t.text || (t.only != null ? 'Send all the light to D' + t.only + ' (at least 98%).' : 'Set D' + t.det + ' to ' + t.pct + '% (±3).')); draw(); };
  const ctl = el('div', { cls: 'row' });
  for (let k = n === 2 ? 1 : 0; k < n; k++) { if (s.mirrors) { const lab = el('span', { cls: 'tiny' }, 'mirror ' + k + ': 0.00 λ'); ctl.append(el('label', { cls: 'col' }, lab, el('input', { type: 'range', min: 0, max: 100, step: 5, value: 0, oninput: e => { ph[k] = TAU * e.target.value / 100; lab.textContent = 'mirror ' + k + ': ' + (e.target.value / 100).toFixed(2) + ' λ'; upd(false); }, onchange: () => upd(true) }))); }
    else ctl.append(DialW({ label: 'φ' + k, onChange: (d, end) => { ph[k] = d * Math.PI / 180; upd(end); } }).el); }
  ctl.append(btn('Confirm setting', () => upd(true), 'sm'));
  c.addEventListener('click', ev => { const [, py] = cpos(c, ev); sel = clamp(Math.round((py - 30) / ((c.H - 60) / (n - 1))), 0, n - 1); upd(false); });
  st.append(row(card(s.mirrors ? 'Slide the mirrors (path length in wavelengths λ)' : 'Turn the phase dials', c, ctl, info), card('Arrows at the chosen detector', PW.el, row(...Array.from({ length: n }, (_, j) => btn('D' + j, () => { sel = j; upd(false); }, 'sm'))), el('div', { cls: 'tiny' }, 'Each path adds one arrow, tip to tail. The white arrow is the total; its length squared is the brightness.'))));
  M = maze(ph); setTask(); upd(false);
};
/* Level 4: the key hall (classical search, guided Grover, rounds, blind) */
function drawKey(x, X, Y, sz, i, col, seed) {
  x.strokeStyle = col; x.fillStyle = col; x.lineWidth = Math.max(1.5, sz / 9);
  x.beginPath(); x.arc(X, Y - sz * 0.55, sz * 0.3, 0, TAU); x.stroke(); x.beginPath(); x.moveTo(X, Y - sz * 0.25); x.lineTo(X, Y + sz * 0.75); x.stroke();
  let h = (i * 2654435761 + seed * 97) >>> 0; for (let k = 0; k < 3; k++) { h = (h * 1103515245 + 12345) >>> 0; const L = sz * (0.14 + 0.2 * ((h >>> 8) % 3) / 2); x.fillRect(X, Y + sz * (0.3 + k * 0.16), L, Math.max(1.5, sz * 0.09)); }
}
COMP.keys = (st, tl, s, ctx) => {
  const Ns = s.Ns || [s.N], mode = s.mode, blind = mode === 'blind'; let N = Ns[0], ni = 0, secret, v = null, alarm = 0, rounds = 0, tried = new Set(), picked = -1, runs = [], xray = !blind, phase = 0, hist = [];
  const c = mkCanvas(560, 190), bars = BarsW({ w: 560, h: 150, mean: true }), chart = mkCanvas(240, 120), info = el('div', { cls: 'note' }), bx = el('div', {}, bars.el);
  const fresh = () => { secret = ctx.rng.int(N); v = null; rounds = 0; tried = new Set(); picked = -1; phase = 0; hist = []; upd(); };
  const draw = () => { const x = c.x, cols = N <= 8 ? N : N === 16 ? 8 : 16, rws = N / cols, cw = 540 / cols, rh = 180 / rws, sz = Math.min(cw * 0.55, rh * 0.42); x.clearRect(0, 0, 560, 190); x.font = Math.max(8, Math.min(12, sz * 0.5)) + 'px system-ui'; x.textAlign = 'center';
    for (let i = 0; i < N; i++) { const X = 10 + (i % cols + 0.45) * cw, Y = 8 + (Math.floor(i / cols) + 0.5) * rh, col = i === picked ? (i === secret ? P.good : P.bad) : tried.has(i) ? '#45285f' : '#efe6ff'; drawKey(x, X, Y, sz, i, col, ctx.seed); x.fillStyle = col; x.fillText(i, X - sz * 0.7, Y + sz * 0.2); } };
  const upd = () => { draw(); bx.style.display = xray && v ? 'block' : 'none'; if (v && xray) { bars.hi = secret; bars.set(v, Array.from({ length: N }, (_, i) => i)); ctx.math('secret amplitude ' + v[secret].toFixed(3) + ' · mean ' + (v.reduce((a, b) => a + b, 0) / N).toFixed(3) + ' · chance ' + (v[secret] ** 2).toFixed(4)); }
    info.innerHTML = 'Keys: <b>' + N + '</b> · alarm points: <b>' + alarm + '</b>' + (mode !== 'classic' ? ' · Mark presses this try: <b>' + rounds + '</b>' : ' · run ' + (runs.length + 1) + ' of 3') + (v && xray ? ' · chance of the right key: <b>' + (v[secret] ** 2 * 100).toFixed(1) + '%</b>' : '');
    if (mode === 'rounds') { const x = chart.x; x.clearRect(0, 0, 240, 120); x.strokeStyle = P.line; x.strokeRect(24, 8, 208, 92); x.fillStyle = P.dim; x.font = '10px system-ui'; x.textAlign = 'center'; x.fillText('chance of the right key vs rounds', 128, 114); x.strokeStyle = P.cyan; x.lineWidth = 2; x.beginPath(); hist.forEach((p, k) => { const X = 30 + k * 196 / Math.max(6, hist.length - 1), Y = 100 - 92 * p; k ? x.lineTo(X, Y) : x.moveTo(X, Y); x.fillStyle = P.cyan; x.fillRect(X - 2, Y - 2, 4, 4); }); x.stroke(); } };
  const need = (k, msg) => { if (mode === 'guided' && phase !== k) { ctx.fb(msg); return false; } return true; };
  const spread = () => { if (!need(0, 'Follow the order: Spread, Mark, Mirror, Look.')) return; v = gSpread(N); rounds = 0; hist = [1 / N]; phase = 1; picked = -1; ctx.fb('Every key now has the same amplitude: a chance of ' + (100 / N).toFixed(1) + '% each.', true); upd(); };
  const mark = q => { if (!v) return ctx.fb('Spread first.'); if (!q && !need(1, 'Mark comes right after Spread.')) return false; gMark(v, secret); alarm++; rounds++; ctx.stat('alarm', 1); phase = 2; if (!q) { ctx.fb('The lock flipped the sign of one key. Its chance has not changed yet.', true); upd(); } return true; };
  const mirror = q => { if (!v) return ctx.fb('Spread first.'); if (!q && !need(2, 'Mirror comes after Mark.')) return; gMirror(v); hist.push(v[secret] ** 2); phase = 3; if (!q) ctx.fb('Every amplitude was reflected about the mean.', true); upd(); };
  const look = () => { if (!v) return ctx.fb('Spread first.'); if (!need(3, 'Do Mark and Mirror before you look.')) return; let r = ctx.rng(), k = 0; for (; k < N - 1; k++) { r -= v[k] * v[k]; if (r <= 0) break; } picked = k; const best = gBest(N), was = v[secret] ** 2; v = null; ctx.move();
    if (mode === 'rounds' && rounds !== best) { phase = 0; upd(); return ctx.fb('You looked after ' + rounds + ' round' + (rounds === 1 ? '' : 's') + ' when the chance was ' + (was * 100).toFixed(1) + '%. The best stop for ' + N + ' keys is a different round. Spread and try again.'); }
    if (k !== secret) { alarm++; ctx.stat('alarm', 1); phase = 0; upd(); return ctx.fb('Key ' + k + ' does not fit (+1 alarm). The superposition is gone: Spread and go again.'); }
    upd(); if (mode === 'rounds' && ++ni < Ns.length) { N = Ns[ni]; ctx.fb('Unlocked at the best round. Now ' + N + ' keys.', true); return fresh(); }
    const lim = blind ? [gBest(N) + 1, gBest(N) + 3] : null; ctx.solve(blind ? { stars: alarm <= lim[0] ? 3 : alarm <= lim[1] ? 2 : 1 } : {}); };
  c.addEventListener('click', ev => { if (mode !== 'classic') return; const [px, py] = cpos(c, ev), cols = N, i = clamp(Math.floor((px - 10) / (540 / cols)), 0, N - 1); if (tried.has(i) || py > 190) return; tried.add(i); picked = i; ctx.move();
    if (i !== secret) { alarm++; upd(); return ctx.fb('Key ' + i + ' does not fit. +1 alarm.'); }
    runs.push(tried.size); upd(); if (runs.length < 3) { ctx.fb('Opened after ' + tried.size + ' tries. Again, with a new secret key.', true); return ctx.after(700, fresh); }
    let tot = 0; for (let t = 0; t < 1000; t++) tot += ctx.rng.int(N) + 1; ctx.fb('Your average: ' + (runs.reduce((a, b) => a + b, 0) / 3).toFixed(1) + ' tries. Over 1000 simulated runs the average is ' + (tot / 1000).toFixed(2) + ', about (N + 1) / 2. The cost grows with N.', true); ctx.solve(); });
  const tools = mode === 'classic' ? el('div', { cls: 'note' }, 'Click a key to try it in the lock.') : row(btn('Spread', spread), btn('Mark (+1 alarm)', () => mark()), btn('Mirror', () => mirror()), mode === 'guided' ? null : btn('Grover round', () => { if (mark(true)) mirror(true); }, 'pri'), btn('Look', look, 'pri'),
    blind ? null : btn('X-ray: on', e => { xray = !xray; e.target.textContent = 'X-ray: ' + (xray ? 'on' : 'off'); upd(); }));
  st.append(card('The key hall', c, tools, info, blind ? null : el('div', { cls: 'tiny' }, 'X-ray is a teaching view: a real quantum computer cannot show this. The bars are AMPLITUDES, not chances. Chance = amplitude × amplitude, so a bar of ±0.50 means 0.50 × 0.50 = 25%. A flipped (pink) bar has the same chance as before; only its sign changed.'), bx, mode === 'rounds' ? chart : null));
  if (mode === 'rounds') ctx.task('For 8, then 16, then 64 keys: stop at the best round and Look. Best rounds ≈ (π/4) × √N.');
  fresh();
};
/* Level 5 prelude: build a Bell pair with H and CNOT */
COMP.bell = (st, tl, s, ctx) => {
  const hist = HistW(['00', '01', '10', '11'], { w: 260, h: 120 }), W = CircuitW({ wires: 2, slots: 3, cards: [['H', 0], ['CX', 0, 1]], names: ['q0', 'q1'], onMsg: m => ctx.fb(m) });
  st.append(row(card('Two qubits', W.el, row(btn('Look ×100 at both', () => { hist.clear(); for (let i = 0; i < 100; i++) { const q = new State(2); W.ops.forEach(o => applyOp(q, o)); const a = q.measure(0, ctx.rng), b = q.measure(1, ctx.rng); hist.add(a * 2 + b); } hist.draw(); ctx.move();
    const okc = W.ops.length === 2 && W.ops[0][0] === 'H' && W.ops[1][0] === 'CX'; if (okc) { ctx.say('Each qubit alone is random, but together they always match. That is entanglement.', 'happy'); ctx.solve(); } else ctx.fb('Not a matched pair yet. Put H on q0 first, then the CNOT from q0 to q1.'); }, 'pri'), btn('Reset', () => W.reset()))), card('Both results (q0 q1)', hist.el)));
  ctx.task('Build H on q0, then CNOT q0→q1. Then look at both, 100 times.');
};
/* Level 5: teleportation on a real 3-qubit state (main, cut line, inspect, relay) */
COMP.teleport = (st, tl, s, ctx) => {
  const mode = s.mode || 'main', total = mode === 'cut' ? 20 : mode === 'relay' ? 2 : (s.rounds || 1); let round = 0, S, secret, orig, m0, m1, phase = 0, manualDone = !!s.auto, bobBase = null, wrong = 0;
  const A = BlochW({ size: 160, view: false, label: 'Crystal (behind the glass)' }), Bo = BlochW({ size: 160, view: false, label: "Your socket (outside)" }), V = BlochW({ size: 130, view: false, label: 'Vault qubit q0 now' });
  const line = mkCanvas(420, 44), info = el('div', { cls: 'note' }), fixRow = el('div', { cls: 'row' }), hist = HistW(['matched', 'scrambled'], { w: 200, h: 100, cols: [P.good, P.bad] }), meter = el('div', { cls: 'meter' }, el('i'));
  const W = CircuitW({ wires: 3, slots: 4, names: ['q0 crystal', 'q1 inside', 'q2 yours'], cards: [['H', 1], ['CX', 1, 2], ['CX', 0, 1], ['H', 0]], locked: true, onMsg: m => ctx.fb(m),
    allow: (op, i) => { if (phase > 1) return false; if (op.join() !== TP_OPS[i].join()) { ctx.fb(i < 2 ? 'First make the pair: H on q1, then CNOT q1→q2.' : 'Now link the secret: CNOT q0→q1, then H on q0.'); return false; } return true; },
    onChange: (k, op) => { if (k !== 'add') return; applyOp(S, op); if (W.ops.length === 2) ctx.fb('Pair made: q1 and q2 are entangled across the wall.', true); if (W.ops.length === 4) { phase = 2; ctx.fb('Secret linked. Now look at q0 and q1.', true); } upd(); } });
  W.el.querySelector('canvas').style.borderBottom = '3px dashed ' + P.bad;
  const drawLine = k => { const x = line.x; x.clearRect(0, 0, 420, 44); x.strokeStyle = phase === 9 ? P.bad : P.dim; x.setLineDash([6, 5]); x.beginPath(); x.moveTo(20, 22); x.lineTo(400, 22); x.stroke(); x.setLineDash([]); x.fillStyle = P.dim; x.font = '11px system-ui'; x.textAlign = 'left'; x.fillText('phone line: two ordinary bits', 20, 10);
    if (phase === 9) { x.fillStyle = P.bad; x.fillText('CUT', 200, 40); } if (k != null) [m0, m1].forEach((b, i) => { const X = 20 + 380 * k - i * 22; x.fillStyle = P.amber; x.fillRect(X - 9, 13, 18, 18); x.fillStyle = '#0d0716'; x.textAlign = 'center'; x.fillText(b, X, 26); }); };
  const begin = () => { secret = round > 0 && mode === 'relay' ? vnorm(Bo.v) : vecOf(Math.acos(2 * ctx.rng() - 1), TAU * ctx.rng()); if (round === 0 || mode !== 'relay') orig = secret; S = tpBuild(secret); phase = 0; m0 = m1 = null; W.reset(); A.hidden = false; A.label = mode === 'relay' ? (round ? 'Relay station' : 'Alice (vault)') : 'Crystal (behind the glass)'; A.set(secret); Bo.ghosts = []; Bo.tgt = null; Bo.label = mode === 'relay' && !round ? 'Relay station' : "Your socket (outside)"; Bo.set([0, 0, 0]); V.el.style.display = 'none'; fixRow.innerHTML = ''; drawLine(); upd(); };
  const auto = () => { if (phase > 1) return; while (W.ops.length < 4) { const op = TP_OPS[W.ops.length]; W.ops.push(op); applyOp(S, op); } W.draw(); phase = 2; lookBoth(); };
  const lookBoth = () => { if (phase !== 2) return ctx.fb('Finish the circuit first.'); m0 = S.measure(0, ctx.rng); m1 = S.measure(1, ctx.rng); A.hidden = true; A.draw(); phase = 3; if (mode === 'inspect') { V.el.style.display = ''; V.set(S.bloch(0)); }
    ctx.fb('Looked. The secret qubit is now just an ordinary ' + m0 + ': the original is gone from the chamber (no-cloning).', true); upd(); if (mode === 'cut') { phase = 9; drawLine(); arrive(); } };
  const send = () => { if (phase !== 3) return ctx.fb('Look at q0 and q1 first.'); phase = 4; const d = ctx.fast() ? CONFIG.animFast : CONFIG.phoneMs, t0 = performance.now(); const f = now => { const k = clamp((now - t0) / d, 0, 1); drawLine(k); if (k < 1 && phase === 4) requestAnimationFrame(f); else if (phase === 4) arrive(); }; requestAnimationFrame(f); upd(); };
  const arrive = () => { if (phase !== 9) phase = 5; bobBase = S.copy(); const bv = S.bloch(2);
    if (phase === 5) { Bo.ghosts = FIXES.map(f => ({ v: f[1].reduce((v, g) => gateVec(v, g), bv), t: f[0] === 'Nothing' ? 'as is' : f[0] })); Bo.set(bv); } else Bo.set([0, 0, 0]);
    fixRow.innerHTML = ''; FIXES.forEach((f, i) => fixRow.append(btn(f[0], () => fix(i)))); upd(); };
  const fix = i => { if (phase !== 5 && phase !== 9) return; const T = bobBase.copy(); FIXES[i][1].forEach(g => T.apply1(g, 2)); const F = fidB(T.bloch(2), secret), okf = F >= CONFIG.tol.fid; ctx.move(); ctx.stat('tp', 1); meter.firstChild.style.width = pct(F); meter.firstChild.style.background = okf ? P.good : P.bad;
    if (mode === 'cut') { hist.add(okf ? 0 : 1); hist.draw(); round++; if (round >= total) { ctx.fb('Matched ' + hist.n[0] + ' of 20: about 1 in 4. No information moves faster than the phone line.', true); return ctx.solve(); } return begin2(); }
    Bo.ghosts = []; Bo.tgt = secret; Bo.set(T.bloch(2));
    if (!okf) { wrong++; return ctx.fb('Fidelity ' + (F * 100).toFixed(0) + '%: that is not the secret. Read the two bits again and pick another fix.'); }
    manualDone = true; round++; if (round >= total) { ctx.fb('Teleported: fidelity ' + (F * 100).toFixed(1) + '%.', true); return ctx.solve(); }
    ctx.fb(mode === 'relay' ? 'Hop 1 done. Now the relay sends it on to Bob.' : 'Teleported. Another secret, please.', true); phase = 8; ctx.after(900, begin); };
  const begin2 = () => { begin(); auto(); };
  const upd = () => { info.innerHTML = (mode === 'cut' ? 'Attempt <b>' + Math.min(round + 1, 20) + '</b> of 20 · the line is cut: Bob must guess.' : (mode === 'relay' ? 'Hop <b>' + (round + 1) + '</b> of 2 · ' : total > 1 ? 'Secret <b>' + (round + 1) + '</b> of ' + total + ' · ' : '') + 'Bits: m0 = <b>' + (m0 == null || phase === 9 ? '?' : m0) + '</b> (from q0), m1 = <b>' + (m1 == null || phase === 9 ? '?' : m1) + '</b> (from q1)') + (phase === 5 ? ' · Choose the fix.' : '');
    if (phase >= 5 && S) ctx.math("your qubit = X^m1 Z^m0 · secret · Bloch (" + S.bloch(2).map(v => v.toFixed(2)).join(', ') + ')'); };
  const sheet = el('table', { cls: 'tbl' }, el('tr', {}, el('th', {}, 'm0 m1'), el('th', {}, 'Fix')), ...[[0, 0], [0, 1], [1, 0], [1, 1]].map(([a, b]) => el('tr', {}, el('td', {}, a + ' ' + b), el('td', {}, el('select', { onchange: e => { e.target.className = +e.target.value === fixFor(a, b) ? 'okc' : 'noc'; } }, el('option', { value: -1 }, '?'), ...FIXES.map((f, i) => el('option', { value: i }, f[0])))))));
  st.append(row(card(null, A.el, V.el), card('Circuit (the dashed red line is the wall)', W.el, row(btn('Look at q0 and q1', lookBoth), mode === 'cut' ? null : btn('Send the bits', send, 'pri'), btn('Run quantum part', () => { if (!manualDone && mode !== 'cut' && mode !== 'inspect') return ctx.fb('Build it by hand once first.'); auto(); })), line, info), card(null, Bo.el, el('div', { cls: 'tiny' }, 'Fidelity with the secret'), meter, fixRow)),
    mode === 'cut' ? card('20 guesses with the line cut', hist.el, btn('Auto-guess the rest', () => { let g = 0; while (round < total && g++ < 40) fix(ctx.rng.int(4)); })) : mode === 'main' ? card('Your cheat sheet (fill it in)', sheet) : null);
  V.el.style.display = 'none'; if (mode === 'cut' || mode === 'inspect') { manualDone = true; begin2(); } else begin();
  ctx.task(mode === 'cut' ? 'Guess a fix 20 times without the bits.' : mode === 'relay' ? 'Teleport Alice → Relay, then Relay → Bob.' : mode === 'inspect' ? 'Watch where the secret goes, then apply the fix.' : 'Make the pair, link the secret, look, send the bits, fix.');
};
/* Level 6: resonance lock, iterative phase estimation */
COMP.pe = (st, tl, s, ctx) => {
  const nd = s.digits, codes = s.fuzzy ? [0] : s.codes || [ctx.rng.int(1 << nd)]; let ci = 0, code, digs, next, busy = false, spin = 0, why = false;
  const lock = mkCanvas(170, 170), B = BlochW({ size: 180, view: false, label: 'probe qubit' }), cap = el('div', { cls: 'note' }), disp = el('div', { cls: 'row' }), pr = el('div', { cls: 'row' }), whyBox = el('div', { cls: 'tiny' }), hist = HistW(Array.from({ length: 16 }, (_, i) => i.toString(2).padStart(4, '0')), { w: 520, h: 130 });
  const phi = () => s.fuzzy ? 0.3 : code / (1 << nd);
  const drawLock = () => { const x = lock.x; x.clearRect(0, 0, 170, 170); x.beginPath(); x.arc(85, 80, 60, 0, TAU); x.fillStyle = '#0d0716'; x.fill(); x.strokeStyle = '#6d4a94'; x.lineWidth = 3; x.stroke(); for (let k = 0; k < 16; k++) { const t = k * TAU / 16; x.strokeStyle = '#45285f'; x.lineWidth = 1; x.beginPath(); x.moveTo(85 + 52 * Math.cos(t), 80 + 52 * Math.sin(t)); x.lineTo(85 + 60 * Math.cos(t), 80 + 60 * Math.sin(t)); x.stroke(); }
    x.strokeStyle = P.amber; x.lineWidth = 4; x.beginPath(); x.moveTo(85, 80); x.lineTo(85 + 46 * Math.cos(spin), 80 - 46 * Math.sin(spin)); x.stroke(); x.fillStyle = P.dim; x.font = '12px system-ui'; x.textAlign = 'center'; x.fillText('hidden twist (you only see it spin)', 85, 160, 166); };
  const upd = () => { disp.innerHTML = ''; disp.append(el('span', { cls: 'tiny' }, 'code digits: '), ...digs.map(d => el('span', { cls: 'digit' + (d == null ? '' : ' on') }, d == null ? '?' : d)));
    pr.innerHTML = ''; for (let k = nd - 1; k >= 0; k--) pr.append(btn('Probe ×' + (1 << k), () => probe(k), k === next ? 'pri' : 'dis')); };
  const probe = k => { if (busy) return; if (k !== next) return ctx.fb(next < 0 ? 'All digits are read. Enter the code on the keypad.' : 'Probe in order: the longest spin first. Next is ×' + (1 << next) + '.');
    busy = true; let corr = 0; for (let j = k + 1; j < nd; j++) corr += digs[j] / Math.pow(2, j - k + 1); const m = 1 << k, r = ipeProbe(phi(), m, TAU * corr, ctx.rng), d = ctx.dur() * 1.4; ctx.move(); ctx.stat('probes', 1);
    const t0 = performance.now(), sp = now => { const e = clamp((now - t0) / d, 0, 1); spin = e * m * TAU; drawLock(); if (e < 1) requestAnimationFrame(sp); }; requestAnimationFrame(sp);
    B.set([1, 0, 0]); cap.textContent = 'The lock spins ' + m + ' time' + (m > 1 ? 's' : '') + '. The twist kicks back onto the probe.';
    whyBox.textContent = why ? 'Angle after ' + m + ' spins = 360° × ' + m + ' × φ (whole turns vanish). Known later digits add ' + (corr * 360).toFixed(1) + '°, which we remove. What is left is 0° (digit 0) or 180° (digit 1).' : '';
    B.anim(vnorm(r.stages[0]), d, () => { const a1 = Math.round(Math.atan2(r.stages[0][1], r.stages[0][0]) * 180 / Math.PI + 360) % 360; cap.textContent = 'Probe angle: ' + a1 + '°. Maya removes the part we already know: −' + (corr * 360).toFixed(1) + '°.';
      B.anim(vnorm(r.stages[1]), d, () => { cap.textContent = 'Final H: north pole reads 0, south pole reads 1.'; B.anim('H', d, () => { digs[k] = r.bit; next = k - 1; busy = false; cap.textContent = 'Digit read: ' + r.bit + (r.p1 > 0.001 && r.p1 < 0.999 ? ' (not certain: chance of 1 was ' + pct(r.p1) + ')' : ' (certain)') + '.'; ctx.math('m = ' + m + ' · correction = −' + (corr * 360).toFixed(1) + '° · P(1) = ' + r.p1.toFixed(3)); upd(); }); }); }); };
  const fresh = () => { code = codes[ci]; digs = Array(nd).fill(null); next = nd - 1; spin = 0; drawLock(); B.set([0, 0, 1]); cap.textContent = 'Lock ' + (ci + 1) + ' of ' + codes.length + '. Start with the longest probe.'; upd(); };
  const pad = KeypadW(nd, val => { if (digs.some(d => d == null)) return ctx.fb('Read every digit first.'); if (val !== code) return ctx.fb('The lock stays shut. Compare the keypad with the digits you read.'); if (++ci < codes.length) { ctx.fb('Open. Next lock.', true); return fresh(); } ctx.solve({ out: code }); });
  if (s.fuzzy) { let runs = 0; st.append(card('The fuzzy lock: hidden angle 0.3 of a turn', row(btn('Run 4 probes ×1', () => go(1)), btn('×10', () => go(10))), hist.el, cap));
    const go = n => { for (let i = 0; i < n && runs < CONFIG.fuzzyRuns; i++, runs++) hist.add(parseInt(ipeRun(0.3, 4, ctx.rng).d.join(''), 2)); hist.draw(); ctx.move(); cap.textContent = runs + ' of ' + CONFIG.fuzzyRuns + ' runs. 0.3 is between 0100 (0.25) and 0101 (0.3125): the results pile up near the closest fractions.'; if (runs >= 20) ctx.solve(); }; return; }
  st.append(row(card('The lock', lock, pr, disp), card('One probe, step by step', B.el, cap, btn('Show me why', e => { why = !why; e.target.classList.toggle('on', why); if (!why) whyBox.textContent = ''; }, 'sm'), whyBox), card('Keypad', pad.el)));
  fresh();
};

'use strict';
/* ===== CONFIG ===== */
const CONFIG = {
  pal: { bg: '#0d0716', panel: '#1c1030', text: '#efe6ff', dim: '#a58fc4', cyan: '#5ef6ff', neg: '#ff3d8b', good: '#35f08f', bad: '#ff6158', amber: '#fcee0a', line: '#4a2a6e' },
  anim: 450, animFast: 90, typeMs: 18,
  tol: { fid1: 0.98, fid: 0.999, dim: 3, det: 0.98 },
  alarmStars: [4, 6], phoneMs: 3000, looks: [1, 10, 100], fuzzyRuns: 50
};
const TAU = Math.PI * 2, SQ = Math.SQRT1_2, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function mkRng(seed) { let a = seed >>> 0; const f = () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; f.int = n => Math.floor(f() * n); return f; }

/* ===== SIM: state-vector simulator, up to 6 qubits. Qubit q is bit q of the basis index. ===== */
const GATES = { H: [SQ, 0, SQ, 0, SQ, 0, -SQ, 0], X: [0, 0, 1, 0, 1, 0, 0, 0], Z: [1, 0, 0, 0, 0, 0, -1, 0] };
class State {
  constructor(n) { this.n = n; this.N = 1 << n; this.re = new Float64Array(this.N); this.im = new Float64Array(this.N); this.re[0] = 1; }
  copy() { const s = new State(this.n); s.re.set(this.re); s.im.set(this.im); return s; }
  apply1(g, q) {
    if (typeof g === 'string') g = GATES[g];
    const m = 1 << q, re = this.re, im = this.im;
    for (let i = 0; i < this.N; i++) { if (i & m) continue; const j = i | m, xr = re[i], xi = im[i], yr = re[j], yi = im[j];
      re[i] = g[0] * xr - g[1] * xi + g[2] * yr - g[3] * yi; im[i] = g[0] * xi + g[1] * xr + g[2] * yi + g[3] * yr;
      re[j] = g[4] * xr - g[5] * xi + g[6] * yr - g[7] * yi; im[j] = g[4] * xi + g[5] * xr + g[6] * yi + g[7] * yr; }
    return this;
  }
  applyCNOT(c, t) { const cm = 1 << c, tm = 1 << t; for (let i = 0; i < this.N; i++) if ((i & cm) && !(i & tm)) { const j = i | tm; let x = this.re[i]; this.re[i] = this.re[j]; this.re[j] = x; x = this.im[i]; this.im[i] = this.im[j]; this.im[j] = x; } return this; }
  applyControlledPhase(c, t, phi) { const m = (1 << c) | (1 << t), cs = Math.cos(phi), sn = Math.sin(phi); for (let i = 0; i < this.N; i++) if ((i & m) === m) { const x = this.re[i], y = this.im[i]; this.re[i] = x * cs - y * sn; this.im[i] = x * sn + y * cs; } return this; }
  phase(q, phi) { const m = 1 << q, cs = Math.cos(phi), sn = Math.sin(phi); for (let i = 0; i < this.N; i++) if (i & m) { const x = this.re[i], y = this.im[i]; this.re[i] = x * cs - y * sn; this.im[i] = x * sn + y * cs; } return this; }
  diag(ph) { for (let i = 0; i < this.N; i++) { const cs = Math.cos(ph[i]), sn = Math.sin(ph[i]), x = this.re[i], y = this.im[i]; this.re[i] = x * cs - y * sn; this.im[i] = x * sn + y * cs; } return this; }
  prob(q) { const m = 1 << q; let p = 0; for (let i = 0; i < this.N; i++) if (i & m) p += this.re[i] ** 2 + this.im[i] ** 2; return p; }
  probs() { return Array.from(this.re, (r, i) => r * r + this.im[i] ** 2); }
  measure(q, rng, force) {
    const m = 1 << q, p1 = this.prob(q), out = force !== undefined ? force : (rng() < p1 ? 1 : 0), s = 1 / Math.sqrt(Math.max(out ? p1 : 1 - p1, 1e-300));
    for (let i = 0; i < this.N; i++) { if (((i & m) ? 1 : 0) === out) { this.re[i] *= s; this.im[i] *= s; } else { this.re[i] = 0; this.im[i] = 0; } }
    return out;
  }
  /* reduced Bloch vector: x = 2Re(a*b), y = 2Im(a*b), z = |a|^2 - |b|^2 */
  bloch(q) { const m = 1 << q; let z = 0, xr = 0, xi = 0; for (let i = 0; i < this.N; i++) { if (i & m) continue; const j = i | m; z += this.re[i] ** 2 + this.im[i] ** 2 - this.re[j] ** 2 - this.im[j] ** 2; xr += this.re[i] * this.re[j] + this.im[i] * this.im[j]; xi += this.re[i] * this.im[j] - this.im[i] * this.re[j]; } return [2 * xr, 2 * xi, z]; }
  /* put qubit q (currently |0>) into cos(th/2)|0> + e^{i ph} sin(th/2)|1> */
  fromBloch(q, th, ph) { const c = Math.cos(th / 2), s = Math.sin(th / 2); return this.apply1([c, 0, -s, 0, s, 0, c, 0], q).phase(q, ph); }
}
const vecOf = (th, ph) => [Math.sin(th) * Math.cos(ph), Math.sin(th) * Math.sin(ph), Math.cos(th)];
const angOf = v => [Math.acos(clamp(v[2], -1, 1)), (Math.atan2(v[1], v[0]) + TAU) % TAU];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], vnorm = a => { const n = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / n, a[1] / n, a[2] / n]; };
const fidB = (a, b) => (1 + dot(a, b)) / 2;
const NAMED = { '0': [0, 0, 1], '1': [0, 0, -1], '+': [1, 0, 0], '-': [-1, 0, 0] }, KET = { '0': '|0⟩', '1': '|1⟩', '+': '|+⟩', '-': '|−⟩' };
const stateOfVec = v => { const a = angOf(vnorm(v)); return new State(1).fromBloch(0, a[0], a[1]); };
const gateVec = (v, g) => stateOfVec(v).apply1(g, 0).bloch(0);
const nameOf = v => Object.keys(NAMED).find(k => fidB(NAMED[k], v) > 0.999) || null;
const runGates = (start, seq) => { let v = NAMED[start] || start; for (const g of seq) v = gateVec(v, g); return v; };
/* shortest gate sequence (breadth-first) from start to target under an inventory; null if unreachable */
function bfsPar(start, target, inv) {
  const key = (v, u) => nameOf(v) + '|' + ['X', 'Z', 'H'].map(g => u[g] || 0).join(','), q = [{ v: NAMED[start], u: {}, seq: [] }], seen = new Set([key(NAMED[start], {})]);
  while (q.length) { const c = q.shift(); if (fidB(c.v, NAMED[target]) > 0.999) return c.seq;
    for (const g of ['X', 'Z', 'H']) { if ((c.u[g] || 0) >= (inv[g] || 0)) continue; const u = Object.assign({}, c.u, { [g]: (c.u[g] || 0) + 1 }), v = gateVec(c.v, g), k = key(v, u); if (!seen.has(k)) { seen.add(k); q.push({ v, u, seq: c.seq.concat(g) }); } } }
  return null;
}
/* Grover on a real amplitude vector */
const gSpread = N => new Float64Array(N).fill(1 / Math.sqrt(N));
const gMark = (v, s) => { v[s] = -v[s]; return v; };
const gMirror = v => { let m = 0; for (const a of v) m += a; m /= v.length; for (let i = 0; i < v.length; i++) v[i] = 2 * m - v[i]; return v; };
const gBest = N => Math.max(1, Math.round(Math.PI / 4 * Math.sqrt(N) - 0.5));
/* interference mazes: returns detector probabilities and the per-path arrows for each detector */
function maze(phases) {
  const n = phases.length === 2 ? 1 : 2, s = new State(n); for (let q = 0; q < n; q++) s.apply1('H', q);
  s.diag(phases); for (let q = 0; q < n; q++) s.apply1('H', q);
  const N = 1 << n, pc = x => (x & 1) + (x >> 1 & 1);
  return { p: s.probs(), arrows: j => phases.map((ph, k) => { const sg = pc(j & k) % 2 ? -1 : 1; return [sg * Math.cos(ph) / N, sg * Math.sin(ph) / N]; }) };
}
/* one probe of iterative phase estimation on a real 2-qubit state: q0 = probe, q1 = lock qubit in |1> */
function ipeProbe(phi, m, corr, rng) {
  const s = new State(2); s.apply1('X', 1).apply1('H', 0);
  for (let k = 0; k < m; k++) s.applyControlledPhase(0, 1, TAU * phi);          // phase kickback, m spins
  const a = s.bloch(0); s.phase(0, -corr); const b = s.bloch(0); s.apply1('H', 0); const c = s.bloch(0);
  return { bit: s.measure(0, rng), stages: [a, b, c], p1: (1 - c[2]) / 2 };
}
function ipeRun(phi, nd, rng) {            // nd probes, last digit first; returns digits d1..dnd and the probe log
  const d = Array(nd).fill(0), log = [];
  for (let k = nd - 1; k >= 0; k--) { let corr = 0; for (let j = k + 1; j < nd; j++) corr += d[j] / Math.pow(2, j - k + 1); const m = 1 << k, r = ipeProbe(phi, m, TAU * corr, rng); d[k] = r.bit; log.push({ m, corr, r }); }
  return { d, log };
}
/* teleportation on a real 3-qubit state: q0 secret, q1 Alice, q2 Bob */
function tpBuild(secret) { const a = angOf(secret), s = new State(3); s.fromBloch(0, a[0], a[1]); return s; }
const TP_OPS = [['H', 1], ['CX', 1, 2], ['CX', 0, 1], ['H', 0]];
const applyOp = (s, op) => op[0] === 'CX' ? s.applyCNOT(op[1], op[2]) : s.apply1(op[0], op[1]);
const FIXES = [['Nothing', []], ['X', ['X']], ['Z', ['Z']], ['X then Z', ['X', 'Z']]], fixFor = (m0, m1) => (m1 ? 1 : 0) + (m0 ? 2 : 0);

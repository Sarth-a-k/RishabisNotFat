
/* ===== COMPONENTS: shared widgets ===== */
const $ = id => document.getElementById(id), P = CONFIG.pal;
function el(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const k in props || {}) { const v = props[k]; if (k === 'style') e.style.cssText = v; else if (k.startsWith('on')) e[k] = v; else if (k === 'html') e.innerHTML = v; else if (k === 'cls') e.className = v; else if (v !== false && v != null) e.setAttribute(k, v); }
  for (const c of kids.flat()) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(c));
  return e;
}
const btn = (t, fn, cls) => el('button', { cls: cls || '', onclick: fn }, t);
const row = (...k) => el('div', { cls: 'row' }, ...k), col = (...k) => el('div', { cls: 'col' }, ...k);
const card = (title, ...k) => el('div', { cls: 'card' }, title ? el('div', { cls: 'ct' }, title) : null, ...k);
const pct = p => Math.round(p * 100) + '%';
function mkCanvas(w, h) { const c = el('canvas'), d = window.devicePixelRatio || 1; c.width = w * d; c.height = h * d; c.style.width = w + 'px'; c.style.height = h + 'px'; c.x = c.getContext('2d'); c.x.scale(d, d); c.W = w; c.H = h; return c; }
const cpos = (c, ev) => { const r = c.getBoundingClientRect(); return [(ev.clientX - r.left) * c.W / r.width, (ev.clientY - r.top) * c.H / r.height]; };
function drag(c, onMove, onEnd) {                       // pointer drag on a canvas (mouse and touch)
  let on = false; c.style.touchAction = 'none';
  c.addEventListener('pointerdown', ev => { on = true; c.setPointerCapture(ev.pointerId); onMove(...cpos(c, ev), ev); });
  c.addEventListener('pointermove', ev => { if (on) onMove(...cpos(c, ev), ev); });
  const end = ev => { if (on) { on = false; if (onEnd) onEnd(...cpos(c, ev), ev); } }; c.addEventListener('pointerup', end); c.addEventListener('pointercancel', end);
}
/* drag-and-drop for DOM cards: drop on any element with data-drop; a plain click calls onClick */
function dragCard(node, payload, onDrop, onClick) {
  node.style.touchAction = 'none';
  node.tabIndex = 0; node.setAttribute('role', 'button'); node.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && onClick) { e.preventDefault(); onClick(payload); } });
  node.addEventListener('pointerdown', ev => {
    const x0 = ev.clientX, y0 = ev.clientY; let ghost = null;
    const mv = e => { if (!ghost && Math.hypot(e.clientX - x0, e.clientY - y0) > 6) { ghost = node.cloneNode(true); ghost.className += ' ghost'; document.body.append(ghost); } if (ghost) { ghost.style.left = e.clientX - 20 + 'px'; ghost.style.top = e.clientY - 18 + 'px'; } };
    const up = e => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
      if (ghost) { ghost.remove(); const t = document.elementFromPoint(e.clientX, e.clientY), d = t && t.closest('[data-drop]'); if (d) onDrop(payload, d.dataset.drop); } else if (onClick) onClick(payload); };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  });
}
/* --- BlochSphere: orthographic, view rotates about the vertical axis --- */
function BlochW(o = {}) {
  const S = o.size || 220, c = mkCanvas(S, S), R = S * 0.36, cx = S / 2, cy = S / 2, EL = 0.3;
  const W = { v: [0, 0, 1], tgt: null, ghosts: [], az: -0.6, shade: null, hidden: false, label: o.label || '' };
  const basis = () => { const a = W.az; return { r: [-Math.sin(a), Math.cos(a), 0], u: [-Math.sin(EL) * Math.cos(a), -Math.sin(EL) * Math.sin(a), Math.cos(EL)], d: [Math.cos(EL) * Math.cos(a), Math.cos(EL) * Math.sin(a), Math.sin(EL)] }; };
  const proj = (v, B) => ({ x: cx + R * dot(v, B.r), y: cy - R * dot(v, B.u), d: dot(v, B.d) });
  W.draw = () => {
    const x = c.x, B = basis(); x.clearRect(0, 0, S, S);
    x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.fillStyle = '#0d0716'; x.fill(); x.strokeStyle = '#6d4a94'; x.lineWidth = 1.2; x.stroke();
    const curve = (f, col) => { for (let k = 0; k < 40; k++) { const a = proj(f(k * TAU / 40), B), b = proj(f((k + 1) * TAU / 40), B); x.strokeStyle = a.d > 0 ? col : '#1c0f2c'; x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(b.x, b.y); x.stroke(); } };
    x.lineWidth = 1;
    for (const z of [-0.5, 0, 0.5]) { const r = Math.sqrt(1 - z * z); curve(t => [r * Math.cos(t), r * Math.sin(t), z], z === 0 ? '#8460ad' : '#45285f'); }
    for (const a of [0, Math.PI / 2]) curve(t => [Math.sin(t) * Math.cos(a), Math.sin(t) * Math.sin(a), Math.cos(t)], '#45285f');
    if (W.shade) for (let i = 0; i < 260; i++) { const z = 1 - 2 * (i + 0.5) / 260, r = Math.sqrt(1 - z * z), t = i * 2.39996, v = [r * Math.cos(t), r * Math.sin(t), z]; if (!W.shade(v)) continue; const p = proj(v, B); x.fillStyle = p.d > 0 ? 'rgba(93,224,138,.55)' : 'rgba(93,224,138,.18)'; x.beginPath(); x.arc(p.x, p.y, 3, 0, TAU); x.fill(); }
    x.font = '11px system-ui'; x.textAlign = 'center'; x.textBaseline = 'middle';
    for (const [v, t] of [[[0, 0, 1], '|0⟩'], [[0, 0, -1], '|1⟩'], [[1, 0, 0], '+X'], [[-1, 0, 0], '−X'], [[0, 1, 0], '+Y'], [[0, -1, 0], '−Y']]) {
      const p = proj(v, B), l = proj([v[0] * 1.24, v[1] * 1.24, v[2] * 1.2], B); x.globalAlpha = p.d >= 0 ? 1 : 0.5; x.fillStyle = '#cdb8e8'; x.beginPath(); x.arc(p.x, p.y, p.d >= 0 ? 2.6 : 1.8, 0, TAU); x.fill(); x.fillText(t, l.x, l.y); x.globalAlpha = 1;
    }
    const dotAt = (v, kind, col) => { const p = proj(v, B), k = p.d >= 0 ? 1 : 0.65; x.globalAlpha = p.d >= 0 ? 1 : 0.5;
      if (kind === 'tgt') { x.beginPath(); x.arc(p.x, p.y, 9 * k, 0, TAU); x.strokeStyle = P.amber; x.lineWidth = 2.5; x.stroke(); }
      else if (kind === 'ghost') { x.beginPath(); x.arc(p.x, p.y, 6 * k, 0, TAU); x.setLineDash([3, 3]); x.strokeStyle = col || '#dccdf0'; x.lineWidth = 1.5; x.stroke(); x.setLineDash([]); }
      else { const o0 = proj([0, 0, 0], B); x.strokeStyle = col; x.lineWidth = 2; x.beginPath(); x.moveTo(o0.x, o0.y); x.lineTo(p.x, p.y); x.stroke(); x.beginPath(); x.arc(p.x, p.y, 6.5 * k, 0, TAU); x.fillStyle = col; x.fill(); x.strokeStyle = '#0d0716'; x.lineWidth = 1.5; x.stroke(); }
      x.globalAlpha = 1; return p; };
    for (const g of W.ghosts) { const p = dotAt(g.v, 'ghost', g.col); if (g.t) { x.fillStyle = '#dccdf0'; x.fillText(g.t, p.x, p.y - 13); } }
    if (W.tgt) dotAt(W.tgt, 'tgt');
    if (W.hidden) { x.fillStyle = P.dim; x.font = '600 34px system-ui'; x.fillText(W.hidden === true ? '?' : W.hidden, cx, cy); }
    else if (W.v) { const n = Math.hypot(...W.v); if (n < 0.05) { x.fillStyle = P.dim; x.beginPath(); x.arc(cx, cy, 5, 0, TAU); x.fill(); x.font = '11px system-ui'; x.fillText('noise', cx, cy + 16); } else dotAt(W.v, 'dot', P.cyan); }
    if (W.label) { x.fillStyle = P.dim; x.font = '12px system-ui'; x.fillText(W.label, cx, S - 8); }
  };
  W.set = v => { W.v = v; W.draw(); };
  W.pick = (px, py) => { const B = basis(); let a = (px - cx) / R, b = -(py - cy) / R; const l = Math.hypot(a, b); let back = false; if (l > 1) { const m = Math.max(0, 2 - l) / l; a *= m; b *= m; back = true; } const d = (back ? -1 : 1) * Math.sqrt(Math.max(0, 1 - a * a - b * b));   /* dragging past the rim wraps round to the far side */ return vnorm([0, 1, 2].map(i => B.r[i] * a + B.u[i] * b + B.d[i] * d)); };
  /* animate: 'X' | 'Z' | 'H' turn half a turn around the gate's axis; a vector target slerps */
  W.anim = (to, dur, cb) => {
    const v0 = W.v.slice(), ax = to === 'X' ? [1, 0, 0] : to === 'Z' ? [0, 0, 1] : to === 'H' ? [SQ, 0, SQ] : null, t0 = performance.now();
    const end = ax ? gateVec(v0, to) : to;
    const f = now => { const t = clamp((now - t0) / Math.max(dur, 1), 0, 1), e = t * t * (3 - 2 * t);
      if (ax) { const a = Math.PI * e, k = dot(ax, v0), cr = [ax[1] * v0[2] - ax[2] * v0[1], ax[2] * v0[0] - ax[0] * v0[2], ax[0] * v0[1] - ax[1] * v0[0]]; W.v = [0, 1, 2].map(i => v0[i] * Math.cos(a) + cr[i] * Math.sin(a) + ax[i] * k * (1 - Math.cos(a))); }
      else { const w = Math.acos(clamp(dot(v0, end), -1, 1)); W.v = w < 1e-3 || Math.abs(w - Math.PI) < 1e-3 ? (e < 0.5 ? v0 : end) : [0, 1, 2].map(i => (Math.sin((1 - e) * w) * v0[i] + Math.sin(e * w) * end[i]) / Math.sin(w)); }
      if (t < 1) { W.draw(); requestAnimationFrame(f); } else { W.v = end; W.draw(); if (cb) cb(); } };
    requestAnimationFrame(f);
  };
  if (o.onPick) drag(c, (px, py) => { W.v = W.pick(px, py); W.draw(); o.onPick(W.v, false); }, () => o.onPick(W.v, true));
  const view = el('input', { type: 'range', min: -180, max: 180, value: -34, cls: 'view', title: 'Rotate the view', oninput: e => { W.az = e.target.value * Math.PI / 180; W.draw(); } });
  W.el = col(c, o.view === false ? null : el('label', { cls: 'tiny' }, 'rotate view ', view),
    o.snaps ? row(...['0', '1', '+', '-'].map(k => btn(KET[k], () => { W.v = NAMED[k].slice(); W.draw(); o.onPick && o.onPick(W.v, true); }, 'sm'))) : null);
  W.el.classList.add('bloch'); W.draw(); return W;
}
/* --- AmplitudeBars: signed amplitudes (cyan up / magenta down) or probabilities --- */
function BarsW(o) {
  const w = o.w || 300, h = o.h || 150, c = mkCanvas(w, h), W = { vals: o.vals || [], labels: o.labels || [], mode: o.mode || 'amp', mean: !!o.mean, hi: -1 };
  W.draw = () => {
    const x = c.x, n = W.vals.length, bw = Math.min(46, (w - 20) / n), x0 = (w - bw * n) / 2, amp = W.mode === 'amp', base = amp ? h / 2 - 6 : h - 24, sc = amp ? h / 2 - 22 : h - 44;
    x.clearRect(0, 0, w, h); x.font = (n > 16 ? 8 : 11) + 'px system-ui'; x.textAlign = 'center';
    x.strokeStyle = P.dim; x.setLineDash([4, 4]); x.beginPath(); x.moveTo(6, base); x.lineTo(w - 6, base); x.stroke(); x.setLineDash([]);
    W.vals.forEach((v, i) => { const bh = v * sc, bx = x0 + i * bw + 2; x.fillStyle = amp ? (v >= 0 ? P.cyan : P.neg) : (i === W.hi ? P.good : '#efe6ff'); x.fillRect(bx, base - Math.max(bh, 0), bw - 4, Math.abs(bh) || 1);
      if (i === W.hi) { x.strokeStyle = P.amber; x.lineWidth = 2; x.strokeRect(bx - 1, base - Math.max(bh, 0) - 1, bw - 2, Math.abs(bh) + 2); }
      x.fillStyle = P.text; if (n <= 16) x.fillText(amp ? (v >= 0 ? '+' : '−') + Math.abs(v).toFixed(2) : pct(v), bx + bw / 2 - 2, amp ? base - bh + (v >= 0 ? -5 : 13) : base - bh - 5);
      x.fillStyle = P.dim; if (n <= 32) x.fillText(W.labels[i] != null ? W.labels[i] : i, bx + bw / 2 - 2, h - 6); });
    if (W.mean && amp) { const m = W.vals.reduce((a, b) => a + b, 0) / n; x.strokeStyle = P.amber; x.setLineDash([6, 4]); x.beginPath(); x.moveTo(6, base - m * sc); x.lineTo(w - 6, base - m * sc); x.stroke(); x.setLineDash([]); x.fillStyle = P.amber; x.textAlign = 'left'; x.fillText('mean', 8, base - m * sc - 4); }
  };
  W.set = (vals, labels) => { W.vals = Array.from(vals); if (labels) W.labels = labels; W.draw(); };
  if (o.onDrag) drag(c, (px, py) => { const n = W.vals.length, bw = Math.min(46, (w - 20) / n), i = clamp(Math.floor((px - (w - bw * n) / 2) / bw), 0, n - 1); o.onDrag(i, clamp((h / 2 - 6 - py) / (h / 2 - 22), -1, 1), false); }, () => o.onDrag(-1, 0, true));
  W.el = c; W.draw(); return W;
}
/* --- Histogram of repeated looks --- */
function HistW(labels, o = {}) {
  const w = o.w || 220, h = o.h || 120, c = mkCanvas(w, h), W = { n: labels.map(() => 0), total: 0 };
  W.draw = () => { const x = c.x, k = labels.length, bw = (w - 16) / k, mx = Math.max(1, ...W.n); x.clearRect(0, 0, w, h); x.font = (k > 8 ? 8 : 11) + 'px system-ui'; x.textAlign = 'center';
    labels.forEach((l, i) => { const bh = (h - 40) * W.n[i] / mx; x.fillStyle = o.cols ? o.cols[i] : '#efe6ff'; x.fillRect(8 + i * bw + 2, h - 20 - bh, bw - 4, bh || 1); x.fillStyle = P.text; if (W.total && k <= 8) x.fillText(W.n[i] + ' (' + pct(W.n[i] / W.total) + ')', 8 + i * bw + bw / 2, h - 24 - bh); x.fillStyle = P.dim; x.fillText(l, 8 + i * bw + bw / 2, h - 6); }); };
  W.add = i => { W.n[i]++; W.total++; }; W.clear = () => { W.n = labels.map(() => 0); W.total = 0; W.draw(); }; W.frac = i => W.total ? W.n[i] / W.total : 0;
  W.el = c; W.draw(); return W;
}
/* --- Phasors: arrows added tip to tail --- */
function PhasorW(o = {}) {
  const S = o.size || 170, c = mkCanvas(S, S), W = {};
  W.draw = (arrows, title) => { const x = c.x, sc = S * 0.42; x.clearRect(0, 0, S, S); x.strokeStyle = P.line; x.beginPath(); x.arc(S / 2, S / 2, sc, 0, TAU); x.stroke();
    let px = S / 2, py = S / 2; const cols = [P.cyan, P.amber, P.neg, '#b9a2ff'];
    const arrow = (dx, dy, col, lw) => { const nx = px + dx * sc, ny = py - dy * sc; x.strokeStyle = col; x.fillStyle = col; x.lineWidth = lw; x.beginPath(); x.moveTo(px, py); x.lineTo(nx, ny); x.stroke(); const a = Math.atan2(ny - py, nx - px); if (Math.hypot(dx, dy) > 0.03) { x.beginPath(); x.moveTo(nx, ny); x.lineTo(nx - 7 * Math.cos(a - 0.4), ny - 7 * Math.sin(a - 0.4)); x.lineTo(nx - 7 * Math.cos(a + 0.4), ny - 7 * Math.sin(a + 0.4)); x.fill(); } px = nx; py = ny; };
    let sx = 0, sy = 0; arrows.forEach((a, i) => { arrow(a[0], a[1], cols[i % 4], 2); sx += a[0]; sy += a[1]; });
    px = S / 2; py = S / 2; arrow(sx, sy, '#fff', 3.5);
    x.fillStyle = P.text; x.font = '11px system-ui'; x.textAlign = 'center'; x.fillText((title || '') + ' brightness ' + pct(sx * sx + sy * sy), S / 2, S - 5); };
  W.el = c; return W;
}
/* --- phase dial 0..360, snaps to 15 degree steps when near (or with Shift) --- */
function DialW(o) {
  const S = 74, c = mkCanvas(S, S + 16), W = { deg: o.deg || 0 };
  W.draw = () => { const x = c.x, a = W.deg * Math.PI / 180; x.clearRect(0, 0, S, S + 16); x.beginPath(); x.arc(S / 2, S / 2, 28, 0, TAU); x.fillStyle = '#0d0716'; x.fill(); x.strokeStyle = '#6d4a94'; x.lineWidth = 2; x.stroke();
    for (let k = 0; k < 12; k++) { const t = k * TAU / 12; x.strokeStyle = '#45285f'; x.beginPath(); x.moveTo(S / 2 + 24 * Math.cos(t), S / 2 - 24 * Math.sin(t)); x.lineTo(S / 2 + 28 * Math.cos(t), S / 2 - 28 * Math.sin(t)); x.stroke(); }
    x.strokeStyle = P.cyan; x.lineWidth = 3; x.beginPath(); x.moveTo(S / 2, S / 2); x.lineTo(S / 2 + 24 * Math.cos(a), S / 2 - 24 * Math.sin(a)); x.stroke();
    x.fillStyle = P.text; x.font = '12px system-ui'; x.textAlign = 'center'; x.fillText((o.label ? o.label + ' ' : '') + Math.round(W.deg) + '°', S / 2, S + 10); };
  drag(c, (px, py, ev) => { let d = (Math.atan2(S / 2 - py, px - S / 2) * 180 / Math.PI + 360) % 360; const s = Math.round(d / 15) * 15; if (ev.shiftKey || Math.abs(d - s) < 5) d = s % 360; W.deg = d; W.draw(); o.onChange(d, false); }, () => o.onChange(W.deg, true));
  W.set = d => { W.deg = d; W.draw(); }; W.el = c; W.draw(); return W;
}
/* --- Keypad: toggle bits with a decimal readout --- */
function KeypadW(n, onOpen) {
  const bits = Array(n).fill(0), out = el('span', { cls: 'big' }), bs = bits.map((_, i) => btn('0', () => { bits[i] ^= 1; upd(); }, 'bit'));
  const upd = () => { bs.forEach((b, i) => { b.textContent = bits[i]; b.classList.toggle('on', !!bits[i]); }); out.textContent = ' = ' + parseInt(bits.join(''), 2); };
  upd(); return { el: row(...bs, out, btn('Open', () => onOpen(parseInt(bits.join(''), 2), bits.slice()), 'pri')), bits };
}
/* --- CircuitBoard: wires with slots; cards are clicked or dragged in; click a placed card to remove it --- */
function CircuitW(o) {
  const W = { ops: [], inv: Object.assign({}, o.inv), max: o.slots || 6 }, wires = o.wires || 1, X0 = o.names ? 116 : 70, c = mkCanvas(Math.max(260, X0 + W.max * 52), 30 + wires * 44), tray = el('div', { cls: 'row' });
  const label = op => op[0] === 'CX' ? 'CNOT q' + op[1] + '→q' + op[2] : wires > 1 ? op[0] + ' on q' + op[1] : op[0];
  W.draw = (hi = -1) => { const x = c.x; x.clearRect(0, 0, c.W, c.H); x.font = '12px system-ui'; x.textBaseline = 'middle';
    for (let q = 0; q < wires; q++) { const y = 30 + q * 44; x.strokeStyle = '#6d4a94'; x.lineWidth = 2; x.beginPath(); x.moveTo(X0 - 26, y); x.lineTo(c.W - 8, y); x.stroke(); x.fillStyle = P.dim; x.textAlign = 'left'; x.fillText(o.names ? o.names[q] : 'q' + q, 4, y); }
    for (let i = 0; i < W.max; i++) { const X = X0 + i * 52, op = W.ops[i];
      if (!op) { for (let q = 0; q < wires; q++) { x.setLineDash([3, 3]); x.strokeStyle = '#45285f'; x.strokeRect(X - 16, 14 + q * 44, 32, 32); x.setLineDash([]); } continue; }
      x.textAlign = 'center';
      if (op[0] === 'CX') { const y1 = 30 + op[1] * 44, y2 = 30 + op[2] * 44; x.strokeStyle = P.amber; x.lineWidth = 2; x.beginPath(); x.moveTo(X, y1); x.lineTo(X, y2); x.stroke(); x.fillStyle = P.amber; x.beginPath(); x.arc(X, y1, 5, 0, TAU); x.fill(); x.beginPath(); x.arc(X, y2, 11, 0, TAU); x.stroke(); x.beginPath(); x.moveTo(X - 11, y2); x.lineTo(X + 11, y2); x.moveTo(X, y2 - 11); x.lineTo(X, y2 + 11); x.stroke(); }
      else { const y = 30 + op[1] * 44; x.fillStyle = i === hi ? P.amber : '#24123a'; x.strokeStyle = P.cyan; x.lineWidth = 1.5; x.fillRect(X - 16, y - 16, 32, 32); x.strokeRect(X - 16, y - 16, 32, 32); x.fillStyle = i === hi ? '#0d0716' : '#fff'; x.font = '600 15px system-ui'; x.fillText(op[0] === 'M' ? '👁' : op[0], X, y + 1); x.font = '12px system-ui'; } } };
  const key = op => op.join('');
  W.add = op => { const k = key(op); if (W.ops.length >= W.max) return o.onMsg && o.onMsg('The board is full: remove a card or Reset.'); if (W.inv[k] !== undefined && W.inv[k] <= 0) return o.onMsg && o.onMsg('No ' + label(op) + ' cards left.'); if (o.allow && !o.allow(op, W.ops.length)) return; if (W.inv[k] !== undefined) W.inv[k]--; W.ops.push(op); upd(); o.onChange && o.onChange('add', op); };
  W.removeAt = i => { if (o.locked || i >= W.ops.length) return; const op = W.ops.splice(i, 1)[0], k = key(op); if (W.inv[k] !== undefined) W.inv[k]++; upd(); o.onChange && o.onChange('remove', op); };
  W.reset = keepInv => { if (!keepInv) for (const op of W.ops) { const k = key(op); if (W.inv[k] !== undefined) W.inv[k]++; } W.ops = []; upd(); };
  function upd() { tray.innerHTML = ''; for (const op of o.cards) { const k = key(op), n = W.inv[k], b = el('div', { cls: 'gcard' + (n === 0 ? ' off' : '') }, label(op), n !== undefined ? el('sub', {}, '×' + n) : null); dragCard(b, op, p => W.add(p), p => W.add(p)); tray.append(b); } W.draw(); }
  c.dataset.drop = 'board'; c.addEventListener('click', ev => { const [px] = cpos(c, ev); W.removeAt(Math.round((px - X0) / 52)); });
  W.el = col(c, tray); upd(); return W;
}

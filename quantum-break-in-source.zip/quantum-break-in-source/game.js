/* ===== GAME: map, movement, dialogue, puzzle overlay, ending ===== */
const KEY = 'quantum-break-in-v1', PREVIEW = false;   // PREVIEW builds show only a picker for the two reworked mini-games
const newState = () => ({ x: 20.5, y: 21.6, solved: {}, items: {}, seen: { street: 1 }, read: {}, flags: {}, step: {}, mute: false, started: false, ended: false });
let S = newState();
function load() { try { const s = localStorage.getItem(KEY); if (s) S = Object.assign(newState(), JSON.parse(s)); } catch (e) { S = newState(); } }
function save() { if (PREVIEW) return; try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* storage unavailable: keep playing in memory */ } }

/* --- sound: everything is synthesised with WebAudio, no files --- */
let AC = null, NB = null;
function ac() { if (S.mute) return null; try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); return AC; } catch (e) { return null; } }
function tone(f0, f1, d, o = {}) {
  const a = ac(); if (!a) return;
  try { const os = a.createOscillator(), gn = a.createGain(), t = a.currentTime + (o.at || 0); os.type = o.type || 'triangle'; os.frequency.setValueAtTime(f0, t); if (f1 && f1 !== f0) os.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + d);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime(o.vol || 0.06, t + Math.min(0.02, d / 4)); gn.gain.exponentialRampToValueAtTime(0.0001, t + d);
    let node = os; if (o.lp) { const fl = a.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = o.lp; os.connect(fl); node = fl; }
    node.connect(gn); gn.connect(a.destination); os.start(t); os.stop(t + d + 0.03); } catch (e) { /* no audio */ }
}
function noise(d, o = {}) {
  const a = ac(); if (!a) return;
  try { if (!NB) { NB = a.createBuffer(1, a.sampleRate * 2, a.sampleRate); const ch = NB.getChannelData(0); for (let k = 0; k < ch.length; k++) ch[k] = Math.random() * 2 - 1; }
    const src = a.createBufferSource(), fl = a.createBiquadFilter(), gn = a.createGain(), t = a.currentTime + (o.at || 0); src.buffer = NB; src.loop = true;
    fl.type = o.type || 'bandpass'; fl.frequency.setValueAtTime(o.f || 1000, t); if (o.f1) fl.frequency.exponentialRampToValueAtTime(o.f1, t + d); fl.Q.value = o.q || 0.8;
    gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime(o.vol || 0.05, t + Math.min(0.03, d / 3)); gn.gain.exponentialRampToValueAtTime(0.0001, t + d);
    src.connect(fl); fl.connect(gn); gn.connect(a.destination); src.start(t, Math.random()); src.stop(t + d + 0.03); } catch (e) { /* no audio */ }
}
const beep = (f, d = 0.09, when = 0, type = 'triangle') => tone(f, f, d, { at: when, type });
function meow(o = {}) {          // a sawtooth voice through a sweeping band-pass: "mee-ow"
  const a = ac(); if (!a) return;
  try { const t = a.currentTime + (o.at || 0), d = o.d || 0.62, p = o.pitch || 1, os = a.createOscillator(), o2 = a.createOscillator(), fl = a.createBiquadFilter(), gn = a.createGain();
    os.type = 'sawtooth'; o2.type = 'triangle';
    for (const [x, m] of [[os, 1], [o2, 2]]) { x.frequency.setValueAtTime(430 * p * m, t); x.frequency.linearRampToValueAtTime(760 * p * m, t + d * 0.28); x.frequency.linearRampToValueAtTime(690 * p * m, t + d * 0.55); x.frequency.linearRampToValueAtTime(380 * p * m, t + d); }
    fl.type = o.muffled ? 'lowpass' : 'bandpass'; fl.Q.value = o.muffled ? 0.7 : 2.2; fl.frequency.setValueAtTime(o.muffled ? 420 : 900, t); if (!o.muffled) { fl.frequency.linearRampToValueAtTime(2300, t + d * 0.3); fl.frequency.linearRampToValueAtTime(1100, t + d); }
    gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime(o.vol || 0.16, t + d * 0.18); gn.gain.setValueAtTime(o.vol || 0.16, t + d * 0.5); gn.gain.exponentialRampToValueAtTime(0.0001, t + d);
    os.connect(fl); o2.connect(fl); fl.connect(gn); gn.connect(a.destination); os.start(t); o2.start(t); os.stop(t + d + 0.05); o2.stop(t + d + 0.05); } catch (e) { /* no audio */ }
}
function purr(d = 1.8) {         // low rumble pulsed about 25 times a second
  const a = ac(); if (!a) return;
  try { const t = a.currentTime, os = a.createOscillator(), lfo = a.createOscillator(), lg = a.createGain(), gn = a.createGain(), fl = a.createBiquadFilter();
    os.type = 'sawtooth'; os.frequency.value = 52; lfo.type = 'square'; lfo.frequency.value = 25; fl.type = 'lowpass'; fl.frequency.value = 420;
    gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime(0.09, t + 0.25); gn.gain.setValueAtTime(0.09, t + d - 0.4); gn.gain.exponentialRampToValueAtTime(0.0001, t + d); lg.gain.value = 0.08;
    lfo.connect(lg); lg.connect(gn.gain); os.connect(fl); fl.connect(gn); gn.connect(a.destination); os.start(t); lfo.start(t); os.stop(t + d + 0.05); lfo.stop(t + d + 0.05); } catch (e) { /* no audio */ }
}
const clunk = (at = 0) => { tone(120, 70, 0.22, { type: 'square', vol: 0.07, at, lp: 600 }); tone(70, 45, 0.35, { type: 'square', vol: 0.07, at: at + 0.12, lp: 400 }); noise(0.12, { f: 300, vol: 0.06, at, type: 'lowpass' }); };
let lastType = 0, lastStep = 0;
const SFX = {
  chime: () => { beep(660); beep(880, 0.12, 0.09); beep(1320, 0.2, 0.2); },
  type: who => { const now = performance.now(); if (now - lastType < 38) return; lastType = now; const f = { finn: 300, maya: 540, prof: 200, sys: 250 }[who] || 300; tone(f + Math.random() * 60, f, 0.028, { type: 'square', vol: who === 'sys' ? 0.012 : 0.022, lp: 2400 }); },
  step: out => { const now = performance.now(); if (now - lastStep < 270) return; lastStep = now; noise(0.06, { f: out ? 1400 : 380, type: out ? 'bandpass' : 'lowpass', vol: out ? 0.03 : 0.05 }); },
  click: () => tone(1100, 700, 0.035, { type: 'square', vol: 0.02 }),
  wrong: () => tone(220, 180, 0.09, { type: 'square', vol: 0.035, lp: 900 }),
  denied: () => { tone(170, 130, 0.16, { type: 'square', vol: 0.05, lp: 800 }); tone(170, 120, 0.2, { type: 'square', vol: 0.05, at: 0.2, lp: 800 }); },
  whoosh: () => noise(0.32, { f: 300, f1: 3200, vol: 0.045, q: 1.5 }),
  back: () => noise(0.25, { f: 2600, f1: 300, vol: 0.035, q: 1.5 }),
  creak: () => { tone(170, 330, 0.5, { type: 'sawtooth', vol: 0.03, lp: 1100 }); tone(330, 210, 0.35, { type: 'sawtooth', vol: 0.025, at: 0.45, lp: 1100 }); clunk(0.75); },
  unlock: () => { tone(1250, 1250, 0.05, { type: 'square', vol: 0.03 }); tone(1650, 1650, 0.07, { type: 'square', vol: 0.03, at: 0.08 }); clunk(0.2); },
  slide: () => { noise(0.5, { f: 500, f1: 180, type: 'lowpass', vol: 0.07 }); clunk(0.45); },
  laserOff: () => { for (let k = 0; k < 4; k++) { tone(1500 - k * 120, 55, 0.5, { type: 'sawtooth', vol: 0.05, at: k * 0.2, lp: 3000 }); noise(0.2, { f: 3500, f1: 250, vol: 0.03, at: k * 0.2 }); } tone(60, 40, 0.6, { type: 'sine', vol: 0.1, at: 0.85 }); },
  pickup: () => { tone(880, 1320, 0.1, { vol: 0.05 }); tone(1320, 1980, 0.16, { vol: 0.05, at: 0.1 }); },
  swipe: () => { noise(0.14, { f: 2600, vol: 0.04 }); beep(1200, 0.06, 0.16, 'square'); beep(1600, 0.1, 0.24, 'square'); clunk(0.4); },
  shimmer: () => [660, 990, 1320, 1760, 2640, 3520].forEach((f, k) => tone(f, f * 1.01, 0.55, { type: 'sine', vol: 0.045, at: k * 0.07 })),
  rumble: () => { noise(1.5, { f: 110, type: 'lowpass', vol: 0.16 }); tone(58, 38, 1.4, { type: 'sine', vol: 0.11 }); for (let k = 0; k < 5; k++) tone(300, 200, 0.05, { type: 'square', vol: 0.03, at: 0.15 + k * 0.22, lp: 900 }); clunk(1.45); },
  paper: () => { noise(0.16, { f: 4500, type: 'highpass', vol: 0.03 }); noise(0.2, { f: 3800, type: 'highpass', vol: 0.025, at: 0.14 }); },
  holo: () => { tone(92, 96, 0.55, { type: 'sawtooth', vol: 0.03, lp: 700 }); tone(1900, 600, 0.3, { type: 'sine', vol: 0.03 }); noise(0.25, { f: 5000, type: 'highpass', vol: 0.015 }); },
  talk: () => { },
  muffled: () => meow({ muffled: true, vol: 0.12, pitch: 0.95 }),
  lid: () => { tone(140, 260, 0.45, { type: 'sawtooth', vol: 0.03, lp: 900 }); noise(0.2, { f: 700, vol: 0.04, at: 0.4 }); },
  meow: () => meow({}),
  meow2: () => { meow({ pitch: 1.12, d: 0.42 }); meow({ pitch: 0.96, d: 0.7, at: 0.55 }); },
  purr: () => purr(2.2)
};
const chime = SFX.chime;

/* --- build the map --- */
const TILE = [];
(function build() {
  for (let y = 0; y < MH; y++) { TILE.push([]); for (let x = 0; x < MW; x++) TILE[y].push('g'); }
  for (let x = 0; x < MW; x++) { TILE[19][x] = 'F'; TILE[20][x] = 'p'; TILE[21][x] = 'r'; TILE[22][x] = 'r'; TILE[23][x] = 'p'; }
  for (let y = 1; y <= 16; y++) for (let x = 2; x <= 37; x++) TILE[y][x] = 'W';
  for (const R of ROOMS) if (!R.out) for (let y = R.r[1]; y <= R.r[3]; y++) for (let x = R.r[0]; x <= R.r[2]; x++) TILE[y][x] = R.t;
  for (const d of DOORWAYS) TILE[d[1]][d[0]] = d[2];
  TILE[17][20] = 'p'; TILE[18][20] = 'p';
  for (const t of THINGS) if (t.kind === 'door') TILE[t.y][t.x] = t.floor;
})();
const thingAt = (x, y) => THINGS.find(t => t.x === x && t.y === y);
const isOpen = t => t.kind === 'door' && !!S.solved[t.id];
const lasersOn = () => !S.solved.laser;
function solid(x, y) {
  if (x < 0 || y < 0 || x >= MW || y >= MH) return true; const c = TILE[y][x]; if (c === 'W' || c === 'F') return true;
  const t = thingAt(x, y); if (t && !isOpen(t)) return true;
  return lasersOn() && y >= 7 && y <= 9 && LASERS.includes(x);
}
const roomAt = (x, y) => ROOMS.find(R => x >= R.r[0] && x <= R.r[2] && y >= R.r[1] && y <= R.r[3]);
const hash = (x, y) => { let h = (x * 374761393 + y * 668265263) >>> 0; h = ((h ^ (h >>> 13)) * 1274126177) >>> 0; return (h >>> 8) / 16777216; };

/* --- player, camera, input --- */
const PL = { face: 0, walk: 0, path: null, goal: null, moving: false };
const keys = {}; let VW = 800, VH = 500, TS = 40, camX = 0, camY = 0, DPR = 1, MODE = 'title';   // MODE: title | play | talk | puzzle | end
const cv = $('cv'), g = cv.getContext('2d');
function resize() { const r = cv.getBoundingClientRect(); DPR = window.devicePixelRatio || 1; VW = Math.max(200, r.width); VH = Math.max(160, r.height); cv.width = VW * DPR; cv.height = VH * DPR; TS = clamp(Math.floor(Math.min(VW / 11, VH / 8)), 28, 52); }
function findPath(tx, ty) {
  const sx = Math.floor(S.x), sy = Math.floor(S.y), prev = new Map(), q = [[sx, sy]], k = (x, y) => y * MW + x; prev.set(k(sx, sy), -1);
  const goals = new Set(); if (!solid(tx, ty)) goals.add(k(tx, ty)); else for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!solid(tx + d[0], ty + d[1])) goals.add(k(tx + d[0], ty + d[1]));
  if (!goals.size) return null;
  for (let i = 0; i < q.length; i++) { const [x, y] = q[i]; if (goals.has(k(x, y))) { const out = []; let c = k(x, y); while (c !== -1 && c !== k(sx, sy)) { out.unshift([c % MW + 0.5, Math.floor(c / MW) + 0.5]); c = prev.get(c); } return out; }
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + d[0], ny = y + d[1]; if (!solid(nx, ny) && !prev.has(k(nx, ny))) { prev.set(k(nx, ny), k(x, y)); q.push([nx, ny]); } } }
  return null;
}
function goTo(tx, ty) { const t = thingAt(tx, ty), p = findPath(tx, ty); if (!p) { if (MODE === 'play') say1('finn', 'I can\'t get there from here.'); return false; } PL.path = p; PL.goal = t && !isOpen(t) && usable(t) ? t : null; if (!p.length && PL.goal) { const o = PL.goal; PL.goal = null; PL.path = null; interact(o); } return true; }
const blocked = (x, y) => { const r = 0.27; return solid(Math.floor(x - r), Math.floor(y - r)) || solid(Math.floor(x + r), Math.floor(y - r)) || solid(Math.floor(x - r), Math.floor(y + r)) || solid(Math.floor(x + r), Math.floor(y + r)); };
const usable = t => !!(t.id && (t.kind !== 'door' || !S.solved[t.id]));
function nearest() { let best = null, bd = 1.45; for (const t of THINGS) { if (!usable(t)) continue; const d = Math.hypot(t.x + 0.5 - S.x, t.y + 0.5 - S.y); if (d < bd) { bd = d; best = t; } } return best; }
function update(dt) {
  if (MODE !== 'play') { PL.moving = false; return; }
  let dx = (keys.ArrowRight || keys.d ? 1 : 0) - (keys.ArrowLeft || keys.a ? 1 : 0), dy = (keys.ArrowDown || keys.s ? 1 : 0) - (keys.ArrowUp || keys.w ? 1 : 0);
  if (dx || dy) { PL.path = null; PL.goal = null; }
  else if (PL.path) { while (PL.path.length && Math.hypot(PL.path[0][0] - S.x, PL.path[0][1] - S.y) < 0.09) PL.path.shift();
    if (PL.path.length) { dx = PL.path[0][0] - S.x; dy = PL.path[0][1] - S.y; } else { PL.path = null; const o = PL.goal; PL.goal = null; if (o) { interact(o); return; } } }
  const l = Math.hypot(dx, dy); PL.moving = l > 0;
  if (l > 0) { const sp = 5.2 * dt, mx = dx / l * Math.min(sp, PL.path ? l : sp), my = dy / l * Math.min(sp, PL.path ? l : sp); if (!blocked(S.x + mx, S.y)) S.x += mx; if (!blocked(S.x, S.y + my)) S.y += my; PL.face = Math.atan2(dy, dx); PL.walk += dt * 11; const Rr = roomAt(Math.floor(S.x), Math.floor(S.y)); SFX.step(!Rr || Rr.out); }
  const R = roomAt(Math.floor(S.x), Math.floor(S.y)); if (R && !S.seen[R.id]) { S.seen[R.id] = 1; save(); enterRoom(R.id); }
}

/* --- dialogue --- */
const DLG = { q: [], cur: null, n: 0, last: 0, cb: null };
function talk(lines, cb) { DLG.q = lines.map(l => ({ who: l[0], text: l[1], sfx: l[2] })); DLG.cb = cb || null; MODE = 'talk'; PL.path = null; $('dlg').style.display = 'flex'; nextLine(); }
const say1 = (who, text) => talk([[who, text]]);
function nextLine() { DLG.cur = DLG.q.shift() || null; DLG.n = 0; DLG.last = performance.now(); if (!DLG.cur) { $('dlg').style.display = 'none'; MODE = 'play'; const cb = DLG.cb; DLG.cb = null; if (cb) cb(); return; } const w = WHO[DLG.cur.who]; $('who').textContent = w[0]; $('who').style.color = w[1]; drawFace(DLG.cur.who); if (DLG.cur.sfx && SFX[DLG.cur.sfx]) SFX[DLG.cur.sfx](); else SFX.talk(DLG.cur.who); paintLine(); }
function paintLine() { const c = DLG.cur; if (!c) return; $('say').textContent = c.text.slice(0, DLG.n); $('more').textContent = DLG.n >= c.text.length ? '▶ tap / Space' : ''; }
function advance() { const c = DLG.cur; if (!c) return; if (DLG.n < c.text.length) { DLG.n = c.text.length; paintLine(); } else nextLine(); }
function drawFace(who) {
  const x = $('face').getContext('2d'); x.clearRect(0, 0, 64, 64); x.lineWidth = 2;
  if (who === 'sys') { x.fillStyle = '#8fa0c2'; x.font = '34px system-ui'; x.textAlign = 'center'; x.fillText('…', 32, 40); return; }
  if (who === 'prof') { x.fillStyle = '#e9e9f2'; for (let i = 0; i < 9; i++) { const a = Math.PI + i * Math.PI / 8; x.beginPath(); x.moveTo(32, 30); x.lineTo(32 + 30 * Math.cos(a), 30 + 26 * Math.sin(a) - (i % 2) * 5); x.lineTo(32 + 22 * Math.cos(a + 0.2), 30 + 18 * Math.sin(a + 0.2)); x.fill(); } }
  x.fillStyle = who === 'maya' ? '#c98d62' : who === 'prof' ? '#e7c4a5' : '#e0b08a'; x.beginPath(); x.arc(32, 35, 17, 0, TAU); x.fill();
  if (who === 'finn') { x.fillStyle = '#20263a'; x.beginPath(); x.arc(32, 31, 18, Math.PI, 0); x.fill(); x.fillRect(13, 27, 38, 5); x.fillStyle = '#111'; x.fillRect(15, 32, 34, 9); x.fillStyle = '#fff'; x.beginPath(); x.arc(25, 36.5, 3, 0, TAU); x.arc(39, 36.5, 3, 0, TAU); x.fill(); x.fillStyle = '#111'; x.beginPath(); x.arc(25.5, 36.5, 1.4, 0, TAU); x.arc(39.5, 36.5, 1.4, 0, TAU); x.fill(); x.strokeStyle = '#7a4a34'; x.beginPath(); x.arc(32, 44, 5, 0.2, Math.PI - 0.2); x.stroke(); }
  if (who === 'maya') { x.fillStyle = '#2a1c2e'; x.beginPath(); x.arc(32, 31, 19, Math.PI * 0.95, Math.PI * 2.05); x.fill(); x.fillRect(13, 30, 6, 22); x.fillRect(45, 30, 6, 22); x.strokeStyle = '#3dd9eb'; x.strokeRect(20, 31, 10, 8); x.strokeRect(34, 31, 10, 8); x.beginPath(); x.moveTo(30, 35); x.lineTo(34, 35); x.stroke(); x.fillStyle = '#111'; x.beginPath(); x.arc(25, 35, 1.5, 0, TAU); x.arc(39, 35, 1.5, 0, TAU); x.fill(); x.strokeStyle = '#7a3b34'; x.beginPath(); x.arc(32, 43, 5, 0.2, Math.PI - 0.2); x.stroke(); x.strokeStyle = '#8fa0c2'; x.beginPath(); x.arc(32, 30, 21, Math.PI * 1.1, Math.PI * 1.9); x.stroke(); x.fillStyle = '#8fa0c2'; x.fillRect(9, 30, 5, 10); }
  if (who === 'prof') { x.strokeStyle = '#ff5fa2'; x.beginPath(); x.arc(25, 35, 5.5, 0, TAU); x.stroke(); x.beginPath(); x.arc(39, 35, 5.5, 0, TAU); x.stroke(); x.fillStyle = '#111'; x.beginPath(); x.arc(26, 35, 1.5, 0, TAU); x.arc(38, 35, 1.5, 0, TAU); x.fill(); x.fillStyle = '#e9e9f2'; x.fillRect(24, 43, 16, 4); }
}

/* --- story triggers --- */
function enterRoom(id) {
  if (id === 'yard') talk([['finn', 'Past the gate. Biggest house on the street, Maya. Lights off.'], ['maya', 'Finn, that is Professor Quark\'s house. The man booby-traps his own fridge. Whatever happens, keep me on the line.']]);
  if (id === 'hall') talk([['sys', 'A hologram flickers to life in the middle of the hall.', 'holo'], ['prof', 'INTRUDER! Welcome, welcome. Every lock in this house obeys the laws of quantum mechanics. You cannot pick them. You cannot smash them. You can only UNDERSTAND them. Ha! As if a burglar ever could.'], ['finn', '...he recorded that in advance, right?'], ['maya', 'He did. And he has clearly never met a burglar with a physicist on speed dial. Try the door on the west wall.']]);
  if (id === 'lab') talk([['finn', 'A lab. Glass everywhere. There is an opening in the north wall.'], ['maya', 'Go through it. And read his whiteboard if you pass it, he writes everything down.']]);
  if (id === 'lib') talk([['finn', 'A library. More books than I have seen in my life.'], ['maya', 'Look for something that holds keys. The study door will need one.']]);
  if (id === 'study') talk([['finn', 'His study. Vault door on the far west wall, I can see it from here.'], ['maya', 'Do not get excited yet. See that glass tube? The vault will not wake up without what is inside it.']]);
  if (id === 'vault') talk([['finn', 'No gold bars. No cash. Just one steel box in the middle of the room.'], ['sys', 'Something inside the box shifts. A faint, muffled sound.', 'muffled'], ['finn', '...Maya, the loot just made a noise.'], ['maya', 'Go and look. Carefully.']]);
}
function interact(t) {
  if (MODE !== 'play') return; PL.path = null;
  if (t.note) { S.read[t.id] = 1; save(); return talk(t.note.map((n, k) => ['sys', n, k ? undefined : 'paper'])); }
  if (t.kind === 'holo') return talk([['prof', 'You cannot pick them. You cannot smash them. You can only UNDERSTAND them!', 'holo'], ['finn', 'Yeah, yeah.']]);
  if (t.kind === 'chest') return ending();
  if (t.id === 'study') { if (S.items.card) { S.solved.study = 1; save(); return talk([['sys', 'You swipe the keycard. The study door unlocks.', 'swipe']]); } return talk([['finn', 'Locked. There is a card reader, no handle.', 'denied'], ['maya', 'Then there is a keycard somewhere. Search the library.']]); }
  if (t.needs === 'crystal' && !S.items.crystal) return talk([['finn', 'The vault door. Four probe buttons and an empty socket. Nothing lights up.', 'denied'], ['maya', 'It needs the crystal\'s state. Deal with the glass chamber first, east side of the study.']]);
  if (t.puzzle) { if (S.solved[t.puzzle]) return talk([['maya', 'Already handled. Keep moving.']]); const P = PUZ[t.puzzle]; if (!S.flags['i_' + t.puzzle]) { S.flags['i_' + t.puzzle] = 1; save(); return talk(P.intro, () => openPuzzle(t.puzzle)); } return openPuzzle(t.puzzle); }
}
function objective() {
  const s = S.solved;
  if (S.ended) return ['Psi the cat is yours. Explore freely.', null];
  if (!s.gate) return ['Get through the garden gate.', 'gate']; if (!s.door) return ['Get past the front door.', 'door']; if (!s.lab) return ['Leave the hall: try the door on the west wall.', 'lab'];
  if (!s.laser) return ['Shut down the laser corridor (panel north of the lab).', 'laser']; if (!s.keys) return ['Find a keycard in the library.', 'keys']; if (!s.study) return ['Use the keycard on the study door (north side of the library).', 'study'];
  if (!s.tele) return ['Get the crystal\'s state out of the glass chamber.', 'tele']; if (!s.vault) return ['Open the vault at the west end of the study.', 'vault']; return ['Open the steel box.', 'chest'];
}

/* --- puzzle overlay: runs the step players against the ctx contract --- */
let RM = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
const G = { id: null, def: null, i: 0, s: null, rng: mkRng(1), moves: 0, hint: 0, solved: false, token: 0, loops: [], timers: [], tries: 0 };
const ctx = {
  get rng() { return G.rng; }, get seed() { return SEED; },
  move(n = 1) { G.moves += n; }, addPar() { }, stat() { }, math() { },
  fb(msg, good) { const f = $('fb'); f.textContent = msg || ''; f.className = good ? 'good' : ''; if (msg && !good) SFX.wrong(); },
  loop(fn) { G.loops.push(fn); }, after(ms, fn) { const tk = G.token; G.timers.push(setTimeout(() => { if (tk === G.token) fn(); }, ms)); },
  dur: () => RM ? CONFIG.animFast : CONFIG.anim, fast: () => RM, task(t) { $('task').textContent = t; if (G.id !== 'gate' && G.s && G.s.tasks) $('now').textContent = '▸ ' + t; },
  say(text) { $('maya').append(el('p', { cls: 'aft' }, text)); },
  solve() { if (G.solved) return; G.solved = true; chime(); ctx.fb('Solved!', true); if (G.s.after) $('maya').append(el('p', { cls: 'aft' }, '✓ ' + G.s.after)); const b = $('bNext'), last = G.i + 1 >= G.def.steps.length; b.style.display = ''; b.textContent = last ? 'Unlock ▶' : 'Next step ▶'; try { b.focus({ preventScroll: true }); b.scrollIntoView({ block: 'nearest' }); } catch (e) { } }
};
function stopStep() { G.token++; G.loops.length = 0; G.timers.forEach(clearTimeout); G.timers.length = 0; $('stage').innerHTML = ''; $('tools').innerHTML = ''; }
function openPuzzle(id) { SFX.whoosh(); G.id = id; G.def = PUZ[id]; G.tries = 0; MODE = 'puzzle'; $('puz').style.display = 'flex'; runStep(Math.min(S.step[id] || 0, G.def.steps.length - 1)); }
function runStep(i) {
  stopStep(); const s = G.def.steps[i]; G.i = i; G.s = s; G.moves = 0; G.hint = 0; G.solved = false; S.step[G.id] = i; save();
  G.rng = mkRng(SEED * 1009 + ORDER.indexOf(G.id) * 97 + i * 13 + G.tries * 7919);
  $('ptitle').textContent = G.def.name + ': ' + G.def.lock; $('pstep').textContent = G.def.idea + ' · step ' + (i + 1) + ' of ' + G.def.steps.length;
  $('maya').innerHTML = ''; s.say.forEach(t => $('maya').append(el('p', { html: t }))); $('task').textContent = ''; $('now').textContent = ''; $('taskcard').style.display = G.id === 'gate' ? '' : 'none'; ctx.fb(''); $('hint').textContent = ''; $('bHint').textContent = 'Ask Maya for a hint'; $('bNext').style.display = 'none';
  COMP[s.t]($('stage'), $('tools'), s, ctx); if (s.task && !s.tasks) ctx.task(s.task); $('pbody').scrollTop = 0;
}
function closePuzzle(done) {
  stopStep(); $('puz').style.display = 'none'; MODE = 'play'; const id = G.id, P = G.def; G.id = null;
  if (PREVIEW) { if (done) chime(); return picker(); }
  if (!done) return SFX.back();
  S.solved[id] = 1; if (id === 'keys') S.items.card = 1; if (id === 'tele') S.items.crystal = 1; save(); const fx = { gate: 'creak', door: 'unlock', lab: 'slide', laser: 'laserOff', keys: 'pickup', tele: 'shimmer', vault: 'rumble' }[id]; talk(P.done.map((l, k) => k ? l : [l[0], l[1], fx]));
}

/* --- ending --- */
function ending() {
  if (S.ended) { SFX.meow(); return showEnd(); }
  talk([['sys', 'A sealed steel box. The label reads: "DO NOT OPEN. SUPERPOSITION IN PROGRESS."'], ['finn', 'This is it. Gold? Diamonds? It is heavy... and it just moved again.', 'muffled'], ['maya', 'Finn. Read me the small print on that label.'],
    ['finn', '"Contents: one cat, one very small quantum trigger. Status: asleep AND awake." What does that even mean?'],
    ['maya', 'It is Schrödinger\'s cat. The most famous thought experiment in physics, and that maniac actually built it. In the textbook the cat is alive and dead at once. Quark was kinder: asleep and awake.'],
    ['maya', 'While the box is shut and nobody looks, the cat is in superposition. Both at once. Exactly like the spinning coin on the garden gate.'], ['finn', 'And if I open it?'], ['maya', 'Then you measure it. One look, one answer. You know how this works now.'],
    ['sys', 'You lift the lid.', 'lid'], ['sys', 'A black cat blinks up at you, stretches, and climbs straight into your loot sack.', 'meow'],
    ['finn', 'A cat. I got through seven quantum locks for a CAT.'], ['maya', 'For THE cat! And you just collapsed her wavefunction. Wide awake, I would say.', 'meow2'],
    ['sys', 'There is a tag on her collar, in tiny handwriting.', 'paper'], ['prof', '"Her name is Psi. If you are reading this, you understood every lock in my house, which makes you the first person I would trust to feed her. Seven a.m. sharp. She bites." — Q.'],
    ['finn', '...Rent is still due Friday, Maya.'], ['maya', 'You walked in a burglar and you are walking out knowing quantum mechanics, with the most valuable cat in science purring in your bag. I would call that a win.', 'purr']],
    () => { S.ended = true; CAT.x = S.x; CAT.y = S.y; save(); chime(); showEnd(); });
}
function drawCatPortrait(c) {
  const x = c.getContext('2d'), w = 220, h = 170; x.clearRect(0, 0, w, h);
  x.fillStyle = '#6d7890'; x.fillRect(30, 96, 160, 64); x.fillStyle = '#8d98ad'; x.beginPath(); x.moveTo(30, 96); x.lineTo(10, 74); x.lineTo(60, 80); x.fill(); x.beginPath(); x.moveTo(190, 96); x.lineTo(210, 74); x.lineTo(160, 80); x.fill();
  x.fillStyle = '#fcee0a'; x.font = '700 11px system-ui'; x.textAlign = 'center'; x.fillText('SUPERPOSITION COLLAPSED', 110, 140);
  x.fillStyle = '#17131f'; x.beginPath(); x.ellipse(110, 72, 44, 38, 0, 0, TAU); x.fill();
  x.beginPath(); x.moveTo(72, 52); x.lineTo(76, 14); x.lineTo(100, 40); x.fill(); x.beginPath(); x.moveTo(148, 52); x.lineTo(144, 14); x.lineTo(120, 40); x.fill();
  x.fillStyle = '#ff8fb0'; x.beginPath(); x.moveTo(79, 44); x.lineTo(80, 26); x.lineTo(92, 40); x.fill(); x.beginPath(); x.moveTo(141, 44); x.lineTo(140, 26); x.lineTo(128, 40); x.fill();
  x.fillStyle = '#35f08f'; x.beginPath(); x.ellipse(93, 68, 9, 11, 0, 0, TAU); x.ellipse(127, 68, 9, 11, 0, 0, TAU); x.fill(); x.fillStyle = '#0b0b10'; x.beginPath(); x.ellipse(93, 68, 3, 9, 0, 0, TAU); x.ellipse(127, 68, 3, 9, 0, 0, TAU); x.fill();
  x.fillStyle = '#ff8fb0'; x.beginPath(); x.moveTo(105, 82); x.lineTo(115, 82); x.lineTo(110, 88); x.fill(); x.strokeStyle = '#c9c2d8'; x.lineWidth = 1.2; x.beginPath(); x.moveTo(110, 88); x.lineTo(110, 93); x.moveTo(110, 93); x.quadraticCurveTo(103, 99, 98, 93); x.moveTo(110, 93); x.quadraticCurveTo(117, 99, 122, 93);
  for (const sgn of [-1, 1]) for (const dy of [-5, 0, 5]) { x.moveTo(110 + sgn * 20, 88); x.lineTo(110 + sgn * 58, 86 + dy * 1.6); } x.stroke();
  x.fillStyle = '#17131f'; x.beginPath(); x.ellipse(84, 100, 12, 8, 0, 0, TAU); x.ellipse(136, 100, 12, 8, 0, 0, TAU); x.fill();
}
function showEnd() {
  const c = el('canvas', { width: 220, height: 170, style: 'width:220px;height:170px;align-self:center' }); drawCatPortrait(c); let pets = 0;
  modal('The loot: Schrödinger\'s cat', c, el('div', { cls: 'note' }, 'Her name is Psi. Until Finn opened the box she was asleep and awake at once. One look settled it. Finn came for gold and left with a cat, and with every idea that guarded her:'),
    el('div', {}, ...ORDER.map((k, i) => el('div', { cls: 'nb' }, el('b', {}, (i + 1) + '. ' + PUZ[k].idea), el('div', { cls: 'tiny' }, 'Learned at ' + PUZ[k].name + '.')))),
    row(btn('Pet Psi', () => { pets++; if (pets % 3 === 0) SFX.meow2(); else if (pets % 2) SFX.purr(); else SFX.meow(); }, 'pri'), btn('Open the notebook', notebook), btn('Play again from the start', () => { const m = S.mute; S = newState(); S.mute = m; S.started = true; save(); closeModal(); intro(); }, 'warn')));
}

/* --- menus --- */
function modal(title, ...kids) { const b = $('mbox'); b.innerHTML = ''; const x = btn('Close', closeModal, 'pri'); b.append(el('h2', {}, title), ...kids, row(x)); $('modal').style.display = 'flex'; try { x.focus({ preventScroll: true }); } catch (e) { } b.scrollTop = 0; }
function closeModal() { if (PREVIEW && MODE === 'title') return; $('modal').style.display = 'none'; if (MODE === 'title') { MODE = 'play'; if (!S.started) { S.started = true; save(); intro(); } } }
function notebook() {
  const n = ORDER.filter(k => S.solved[k]).length;
  modal('Finn\'s notebook (' + n + ' of ' + ORDER.length + ' ideas)', el('div', {}, ...ORDER.map(k => { const ok = S.solved[k], P = PUZ[k]; return el('div', { cls: 'nb' + (ok ? '' : ' locked') }, el('b', {}, ok ? P.idea : '??? (' + P.name + ')'), el('div', {}, ok ? P.learn : 'Not cracked yet.')); })),
    el('div', { cls: 'tiny' }, 'Notes found around the house: ' + Object.keys(S.read).length + ' of 3.'));
}
function menu() {
  let armed = false; const rs = btn('Start over', () => { if (!armed) { armed = true; rs.textContent = 'Press again to erase progress'; return; } const m = S.mute; S = newState(); S.mute = m; S.started = true; save(); $('modal').style.display = 'none'; MODE = 'play'; intro(); }, 'warn');
  modal('Menu', el('div', { cls: 'note', html: '<b>Move:</b> <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> or arrow keys, or click / tap where you want to go.<br><b>Interact:</b> <kbd>E</kbd> or <kbd>Space</kbd>, or click / tap the object.<br><b>Map:</b> the plan of the house is in the top-right corner. The amber dot is your next goal.' }), row(rs), el('div', { cls: 'tiny' }, 'Puzzle seed ' + SEED + '. Add ?seed=' + SEED + ' to the address to get the same puzzles again.'));
}
function picker() {
  MODE = 'title'; const b = $('mbox'); b.innerHTML = '';
  b.append(el('h2', {}, 'PREVIEW: THE TWO REWORKED MINI-GAMES'), el('div', { cls: 'note' }, 'This preview skips the house and opens the two redesigned locks directly. "Step back" inside a mini-game returns here.'),
    btn('The Glass Chamber (teleportation) — 3 steps', () => { $('modal').style.display = 'none'; S.step = {}; openPuzzle('tele'); }, 'pri'), btn('The Vault (phase estimation) — 2 steps', () => { $('modal').style.display = 'none'; S.step = {}; openPuzzle('vault'); }, 'pri'),
    el('div', { cls: 'tiny' }, 'Or jump straight to one step:'), row(...[['tele', 1, 'Relay: 1 wall'], ['tele', 2, 'Relay: 3 walls'], ['vault', 0, 'Dial: practice'], ['vault', 1, 'Dial: real vault']].map(a => btn(a[2], () => { $('modal').style.display = 'none'; S.step = { [a[0]]: a[1] }; openPuzzle(a[0]); }))));
  $('modal').style.display = 'flex';
}
function title() {
  if (PREVIEW) return picker();
  const cont = S.started; MODE = 'title';
  const b = $('mbox'); b.innerHTML = ''; const go = btn(cont ? 'Continue' : 'Start the break-in', closeModal, 'pri');
  b.append(el('h2', {}, 'THE QUANTUM BREAK-IN'), el('div', { cls: 'note' }, 'Finn is broke, desperate, and about to rob the richest house on Marigold Lane. Bad choice: it belongs to Professor Quark, a mad scientist who protects everything he owns with quantum locks.'),
    el('div', { cls: 'note' }, 'Good news: Finn\'s childhood friend Maya is a quantum physicist, and she is on the phone. Walk through the house, and she will teach you the physics you need to open every lock.'),
    el('div', { cls: 'tiny', html: 'Move with <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> / arrows or by tapping the map. Interact with <kbd>E</kbd> / <kbd>Space</kbd> or by tapping an object. Nothing can be failed; every puzzle has hints.' }),
    row(go, cont ? btn('New game', () => { const m = S.mute; S = newState(); S.mute = m; closeModal(); }, 'warn') : null));
  $('modal').style.display = 'flex'; go.focus();
}
function intro() { S.x = 20.5; S.y = 21.6; talk([['finn', 'Okay. Rent is due Friday, the fridge is empty, and this street smells like money. One house. In and out.'], ['maya', 'Finn. It is two in the morning. Why is there wind on your microphone?'], ['finn', 'No reason. Hypothetically, Maya, if a gate had a weird science lock on it...'], ['maya', '...I am going to regret this. Fine. Show me the lock. The gate is straight ahead of you, to the north.']]); }

/* --- drawing the world --- */
const FL = { h: ['#5b4633', '#4f3c2b'], l: ['#2b4a52', '#254148'], c: ['#3b2f4d', '#342944'], b: ['#55343a', '#4b2d33'], s: ['#34436a', '#2d3b5e'], v: ['#474f5e', '#3f4654'] };
const seenAt = (x, y) => { const R = roomAt(x, y); return R ? (R.out || !!S.seen[R.id]) : null; };
const thingSeen = o => { const a = seenAt(o.x, o.y); if (a !== null) return a; return [[1, 0], [-1, 0], [0, 1], [0, -1]].some(d => seenAt(o.x + d[0], o.y + d[1]) === true || TILE[o.y + d[1]][o.x + d[0]] === 'g'); };
function drawTile(c, x, y, px, py, t) {
  const h = hash(x, y);
  if (c !== 'W' && seenAt(x, y) === false) { g.fillStyle = '#0d1322'; g.fillRect(px, py, TS + 1, TS + 1); return; }
  if (c === 'g' || c === 'F') { g.fillStyle = h > 0.5 ? '#1e3d2a' : '#214330'; g.fillRect(px, py, TS + 1, TS + 1); g.fillStyle = '#2c5a3c'; for (let i = 0; i < 3; i++) { const a = hash(x * 7 + i, y * 3 + i), b = hash(x + i * 5, y * 11); g.fillRect(px + a * (TS - 3), py + b * (TS - 5), 2, 4); }
    if (h > 0.93 && c === 'g') { g.fillStyle = '#ffb84d'; g.beginPath(); g.arc(px + TS * 0.5, py + TS * 0.5, TS * 0.07, 0, TAU); g.fill(); }
    if (c === 'F') { g.fillStyle = '#8a7652'; g.fillRect(px, py + TS * 0.42, TS + 1, TS * 0.1); g.fillRect(px, py + TS * 0.66, TS + 1, TS * 0.1); g.fillStyle = '#b29a6c'; for (const o of [0.12, 0.62]) { g.fillRect(px + TS * o, py + TS * 0.2, TS * 0.2, TS * 0.7); g.beginPath(); g.moveTo(px + TS * o, py + TS * 0.2); g.lineTo(px + TS * (o + 0.1), py + TS * 0.08); g.lineTo(px + TS * (o + 0.2), py + TS * 0.2); g.fill(); } } return; }
  if (c === 'p') { g.fillStyle = '#5d5a55'; g.fillRect(px, py, TS + 1, TS + 1); g.strokeStyle = '#4b4944'; g.lineWidth = 1; g.strokeRect(px + 0.5, py + 0.5, TS / 2, TS / 2); g.strokeRect(px + TS / 2 + 0.5, py + TS / 2 + 0.5, TS / 2, TS / 2); return; }
  if (c === 'r') { g.fillStyle = '#2a2d36'; g.fillRect(px, py, TS + 1, TS + 1); if (y === 22 && x % 2 === 0) { g.fillStyle = '#c9c28a'; g.fillRect(px + TS * 0.15, py - 2, TS * 0.7, 4); } return; }
  if (c === 'W') { const below = y + 1 < MH && TILE[y + 1][x] !== 'W'; g.fillStyle = '#232a44'; g.fillRect(px, py, TS + 1, TS + 1); g.fillStyle = '#39446e'; g.fillRect(px, py, TS + 1, TS * (below ? 0.45 : 1) + 1); if (below) { g.fillStyle = '#2b3355'; g.fillRect(px, py + TS * 0.45, TS + 1, TS * 0.55 + 1); g.fillStyle = '#1b2036'; g.fillRect(px, py + TS * 0.93, TS + 1, TS * 0.07 + 1); } return; }
  const f = FL[c] || FL.h; g.fillStyle = f[(x + y) % 2]; g.fillRect(px, py, TS + 1, TS + 1);
  if (c === 'h' || c === 'b' || c === 's') { g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 1; g.beginPath(); g.moveTo(px, py + TS / 2); g.lineTo(px + TS, py + TS / 2); g.moveTo(px + TS * (h > 0.5 ? 0.3 : 0.7), py); g.lineTo(px + TS * (h > 0.5 ? 0.3 : 0.7), py + TS / 2); g.stroke(); }
  if (c === 'v') { g.fillStyle = 'rgba(255,255,255,.12)'; for (const a of [0.12, 0.88]) for (const b of [0.12, 0.88]) { g.beginPath(); g.arc(px + TS * a, py + TS * b, 1.5, 0, TAU); g.fill(); } }
  if (c === 'c') { g.fillStyle = 'rgba(255,95,162,.08)'; g.fillRect(px, py + TS * 0.4, TS + 1, TS * 0.2); }
}
function rr(x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function drawThing(o, px, py, t) {
  const T = TS, cx = px + T / 2, cy = py + T / 2;
  switch (o.kind) {
    case 'door': { if (isOpen(o)) { g.fillStyle = 'rgba(93,224,138,.35)'; g.fillRect(px, py, T, T * 0.12); g.fillRect(px, py + T * 0.88, T, T * 0.12); return; }
      const col = o.style === 'vault' ? '#8d98ad' : o.style === 'gate' ? '#8a7652' : '#7a4b2c'; g.fillStyle = col; rr(px + 1, py + 1, T - 2, T - 2, 4); g.fill(); g.strokeStyle = '#0b1220'; g.lineWidth = 2; g.stroke();
      if (o.style === 'vault') { g.strokeStyle = '#3b4350'; g.beginPath(); g.arc(cx, cy, T * 0.28, 0, TAU); g.stroke(); for (let i = 0; i < 4; i++) { const a = t / 1500 + i * Math.PI / 2; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * T * 0.28, cy + Math.sin(a) * T * 0.28); g.stroke(); } }
      else if (o.style === 'gate') { g.strokeStyle = '#5d4d33'; for (let i = 1; i < 4; i++) { g.beginPath(); g.moveTo(px + T * i / 4, py + 3); g.lineTo(px + T * i / 4, py + T - 3); g.stroke(); } }
      g.fillStyle = o.needs && !S.items[o.needs] ? P.bad : P.amber; g.beginPath(); g.arc(cx, cy, T * 0.11, 0, TAU); g.fill(); return; }
    case 'panel': g.fillStyle = '#20263a'; rr(px + T * 0.15, py + T * 0.1, T * 0.7, T * 0.8, 4); g.fill(); g.fillStyle = S.solved.laser ? P.good : P.bad; g.fillRect(px + T * 0.25, py + T * 0.2, T * 0.5, T * 0.22); g.fillStyle = P.cyan; for (let i = 0; i < 3; i++) { g.beginPath(); g.arc(px + T * (0.3 + i * 0.2), py + T * 0.66, T * 0.07, 0, TAU); g.fill(); } return;
    case 'cabinet': g.fillStyle = '#6b4a2e'; rr(px + 2, py + 2, T - 4, T - 4, 3); g.fill(); g.strokeStyle = '#3a2717'; g.lineWidth = 2; g.stroke(); g.beginPath(); g.moveTo(cx, py + 3); g.lineTo(cx, py + T - 3); g.stroke(); g.fillStyle = P.amber; for (let i = 0; i < 4; i++) g.fillRect(px + T * (0.18 + (i % 2) * 0.5), py + T * (0.25 + (i > 1 ? 0.3 : 0)), T * 0.14, T * 0.14); return;
    case 'chamber': { g.fillStyle = '#20263a'; g.beginPath(); g.ellipse(cx, py + T * 0.85, T * 0.4, T * 0.12, 0, 0, TAU); g.fill(); g.fillStyle = 'rgba(160,220,255,.16)'; rr(px + T * 0.18, py + T * 0.02, T * 0.64, T * 0.82, T * 0.2); g.fill(); g.strokeStyle = 'rgba(200,235,255,.6)'; g.lineWidth = 1.5; g.stroke();
      const lit = !S.solved.tele; g.fillStyle = lit ? P.cyan : '#44506b'; g.shadowColor = P.cyan; g.shadowBlur = lit ? 12 + 5 * Math.sin(t / 300) : 0; g.beginPath(); g.moveTo(cx, py + T * 0.22); g.lineTo(cx + T * 0.14, cy); g.lineTo(cx, py + T * 0.7); g.lineTo(cx - T * 0.14, cy); g.fill(); g.shadowBlur = 0; return; }
    case 'chest': g.fillStyle = '#6d7890'; rr(px + T * 0.1, py + T * 0.22, T * 0.8, T * 0.66, 3); g.fill(); g.strokeStyle = '#3b4350'; g.lineWidth = 2; g.stroke(); if (S.ended) { g.fillStyle = '#12151c'; g.fillRect(px + T * 0.18, py + T * 0.3, T * 0.64, T * 0.3); g.fillStyle = '#8d98ad'; g.fillRect(px + T * 0.06, py + T * 0.1, T * 0.88, T * 0.1); } else { const wob = Math.sin(t / 130) > 0.93 ? 1.5 : 0; g.fillStyle = '#8d98ad'; rr(px + T * 0.06 + wob, py + T * 0.14, T * 0.88, T * 0.2, 3); g.fill(); g.fillStyle = P.amber; g.font = '800 ' + Math.round(T * 0.34) + 'px system-ui'; g.textAlign = 'center'; g.fillText('?', cx, py + T * 0.74); } return;
    case 'holo': { g.fillStyle = '#20263a'; g.beginPath(); g.ellipse(cx, py + T * 0.8, T * 0.36, T * 0.13, 0, 0, TAU); g.fill(); const a = 0.35 + 0.2 * Math.sin(t / 200); g.fillStyle = 'rgba(255,95,162,' + a + ')'; g.beginPath(); g.moveTo(cx - T * 0.3, py + T * 0.78); g.lineTo(cx - T * 0.2, py); g.lineTo(cx + T * 0.2, py); g.lineTo(cx + T * 0.3, py + T * 0.78); g.fill(); g.fillStyle = 'rgba(255,255,255,' + (a + 0.2) + ')'; g.beginPath(); g.arc(cx, py + T * 0.3, T * 0.13, 0, TAU); g.fill(); g.fillRect(cx - T * 0.12, py + T * 0.45, T * 0.24, T * 0.22); return; }
    case 'board': g.fillStyle = '#e8eefc'; rr(px + 2, py + T * 0.15, T - 4, T * 0.6, 3); g.fill(); g.strokeStyle = '#3b4670'; g.lineWidth = 2; g.stroke(); g.strokeStyle = '#33456b'; g.lineWidth = 1; g.beginPath(); g.arc(cx, py + T * 0.45, T * 0.16, 0, TAU); g.moveTo(px + T * 0.15, py + T * 0.3); g.lineTo(px + T * 0.4, py + T * 0.3); g.stroke(); return;
    case 'table': case 'desk': g.fillStyle = o.kind === 'desk' ? '#6b4a2e' : '#7b5a3a'; rr(px, py + T * 0.15, T, T * 0.7, 3); g.fill(); g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(px, py + T * 0.78, T, T * 0.07); if (o.note) { g.fillStyle = o.kind === 'desk' ? '#ffe27a' : '#f3ecd8'; g.save(); g.translate(cx, cy); g.rotate(-0.15); g.fillRect(-T * 0.22, -T * 0.2, T * 0.44, T * 0.34); g.restore(); } return;
    case 'bench': g.fillStyle = '#9aa7c2'; rr(px, py + T * 0.2, T, T * 0.6, 2); g.fill(); g.fillStyle = (o.x % 2 ? P.good : P.neg); g.globalAlpha = 0.85; g.beginPath(); g.arc(cx, cy - T * 0.02, T * 0.14, 0, TAU); g.fill(); g.globalAlpha = 1; g.fillStyle = '#e8eefc'; g.fillRect(cx - T * 0.05, cy - T * 0.3, T * 0.1, T * 0.16); return;
    case 'shelf': g.fillStyle = '#4a321f'; g.fillRect(px + 1, py + 1, T - 2, T - 2); for (let r = 0; r < 2; r++) for (let i = 0; i < 5; i++) { g.fillStyle = ['#b5524c', '#4c7fb5', '#c9a13f', '#5d9b6a', '#8a62b0'][Math.floor(hash(o.x * 5 + i, o.y + r) * 5)]; g.fillRect(px + T * (0.1 + i * 0.16), py + T * (0.12 + r * 0.45), T * 0.13, T * 0.34); } return;
    case 'plant': g.fillStyle = '#8a5a3c'; rr(px + T * 0.3, py + T * 0.55, T * 0.4, T * 0.35, 3); g.fill(); g.fillStyle = '#3f8f5a'; for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.5; g.beginPath(); g.ellipse(cx + Math.cos(a) * T * 0.2, py + T * 0.5 + Math.sin(a) * T * 0.22, T * 0.1, T * 0.22, a + Math.PI / 2, 0, TAU); g.fill(); } return;
    case 'coil': g.fillStyle = '#6d7890'; g.fillRect(cx - T * 0.08, py + T * 0.2, T * 0.16, T * 0.65); g.fillStyle = '#c9a13f'; g.beginPath(); g.arc(cx, py + T * 0.22, T * 0.2, 0, TAU); g.fill(); if (Math.sin(t / 90 + 1) > 0.6) { g.strokeStyle = '#bfe9ff'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(cx, py + T * 0.2); g.lineTo(cx + T * 0.3, py - T * 0.05); g.lineTo(cx + T * 0.2, py + T * 0.1); g.lineTo(cx + T * 0.45, py - T * 0.1); g.stroke(); } return;
    case 'crate': g.fillStyle = '#566078'; rr(px + 3, py + 3, T - 6, T - 6, 2); g.fill(); g.strokeStyle = '#353c4d'; g.lineWidth = 2; g.stroke(); g.beginPath(); g.moveTo(px + 3, py + 3); g.lineTo(px + T - 3, py + T - 3); g.stroke(); return;
  }
}
const CAT = { x: 11.5, y: 4.5, f: 0 };
function updateCat(dt) { if (!S.ended) return; const tx = S.x - Math.cos(PL.face) * 0.85, ty = S.y - Math.sin(PL.face) * 0.85 + 0.1, dx = tx - CAT.x, dy = ty - CAT.y, d = Math.hypot(dx, dy); if (d > 6) { CAT.x = tx; CAT.y = ty; } else if (d > 0.25) { const v = Math.min(d, 6.5 * dt); CAT.x += dx / d * v; CAT.y += dy / d * v; CAT.f = Math.atan2(dy, dx); } }
function drawCat(px, py, t) {
  const T = TS, fx = Math.cos(CAT.f), fy = Math.sin(CAT.f); g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(px, py + T * 0.16, T * 0.2, T * 0.08, 0, 0, TAU); g.fill();
  g.strokeStyle = '#17131f'; g.lineWidth = T * 0.07; g.lineCap = 'round'; g.beginPath(); g.moveTo(px - fx * T * 0.16, py - fy * T * 0.12); g.quadraticCurveTo(px - fx * T * 0.36 + Math.sin(t / 220) * T * 0.1, py - fy * T * 0.3 - T * 0.1, px - fx * T * 0.34, py - fy * T * 0.3 - T * 0.24); g.stroke(); g.lineCap = 'butt';
  g.fillStyle = '#17131f'; g.beginPath(); g.ellipse(px, py, T * 0.19, T * 0.15, 0, 0, TAU); g.fill();
  const hx = px + fx * T * 0.16, hy = py + fy * T * 0.1 - T * 0.1; g.beginPath(); g.arc(hx, hy, T * 0.12, 0, TAU); g.fill();
  g.beginPath(); g.moveTo(hx - T * 0.11, hy - T * 0.04); g.lineTo(hx - T * 0.09, hy - T * 0.19); g.lineTo(hx - T * 0.01, hy - T * 0.1); g.fill(); g.beginPath(); g.moveTo(hx + T * 0.11, hy - T * 0.04); g.lineTo(hx + T * 0.09, hy - T * 0.19); g.lineTo(hx + T * 0.01, hy - T * 0.1); g.fill();
  if (fy > -0.5) { g.fillStyle = '#35f08f'; g.beginPath(); g.arc(hx - T * 0.045, hy, T * 0.025, 0, TAU); g.arc(hx + T * 0.045, hy, T * 0.025, 0, TAU); g.fill(); }
}
function drawPlayer(px, py, t) {
  const T = TS, bob = PL.moving ? Math.sin(PL.walk) * T * 0.04 : 0, f = PL.face, fx = Math.cos(f), fy = Math.sin(f);
  g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(px, py + T * 0.28, T * 0.3, T * 0.12, 0, 0, TAU); g.fill();
  g.fillStyle = '#b29a6c'; g.beginPath(); g.arc(px - fx * T * 0.22, py - fy * T * 0.16 + bob - T * 0.02, T * 0.19, 0, TAU); g.fill(); g.strokeStyle = '#7d6a45'; g.lineWidth = 1.5; g.stroke();   // loot sack
  g.save(); g.beginPath(); g.ellipse(px, py + T * 0.08 + bob, T * 0.24, T * 0.26, 0, 0, TAU); g.clip(); g.fillStyle = '#f0f0f0'; g.fillRect(px - T, py - T, 2 * T, 2 * T); g.fillStyle = '#1b1f2e'; for (let i = -3; i < 4; i++) g.fillRect(px - T * 0.3, py + bob + i * T * 0.12, T * 0.6, T * 0.06); g.restore();
  g.fillStyle = '#e0b08a'; g.beginPath(); g.arc(px, py - T * 0.18 + bob, T * 0.19, 0, TAU); g.fill();
  g.fillStyle = '#20263a'; g.beginPath(); g.arc(px, py - T * 0.22 + bob, T * 0.195, Math.PI, 0); g.fill();                                     // beanie
  if (fy > -0.5) { g.fillStyle = '#111'; g.fillRect(px - T * 0.19, py - T * 0.22 + bob, T * 0.38, T * 0.09); g.fillStyle = '#fff'; g.beginPath(); g.arc(px - T * 0.07 + fx * T * 0.05, py - T * 0.175 + bob, T * 0.035, 0, TAU); g.arc(px + T * 0.07 + fx * T * 0.05, py - T * 0.175 + bob, T * 0.035, 0, TAU); g.fill(); }
}
function drawMini(t) {
  const k = clamp(Math.floor(Math.min(VW * 0.3, 190) / MW), 2, 5), w = MW * k, h = MH * k, ox = VW - w - 10, oy = 10;
  g.fillStyle = 'rgba(11,18,32,.85)'; rr(ox - 5, oy - 5, w + 10, h + 10, 6); g.fill(); g.strokeStyle = '#2a3a5c'; g.lineWidth = 1; g.stroke();
  for (const R of ROOMS) { if (!S.seen[R.id] && !R.out) { g.fillStyle = '#1a2338'; g.fillRect(ox + R.r[0] * k, oy + R.r[1] * k, (R.r[2] - R.r[0] + 1) * k, (R.r[3] - R.r[1] + 1) * k); g.fillStyle = '#56648a'; g.font = k * 3 + 'px system-ui'; g.textAlign = 'center'; g.fillText('?', ox + (R.r[0] + R.r[2] + 1) / 2 * k, oy + (R.r[1] + R.r[3] + 1) / 2 * k + k); continue; }
    g.fillStyle = R.out ? (R.id === 'street' ? '#3a3d48' : '#2c5a3c') : FL[R.t][0]; g.fillRect(ox + R.r[0] * k, oy + R.r[1] * k, (R.r[2] - R.r[0] + 1) * k, (R.r[3] - R.r[1] + 1) * k); }
  g.strokeStyle = '#6d7aa6'; g.strokeRect(ox + 2 * k, oy + 1 * k, 36 * k, 16 * k);
  for (const o of THINGS) if (o.kind === 'door') { g.fillStyle = isOpen(o) ? P.good : P.bad; g.fillRect(ox + o.x * k - 0.5, oy + o.y * k - 0.5, k + 1, k + 1); }
  if (lasersOn() && S.seen.corr) { g.fillStyle = P.bad; for (const x of LASERS) g.fillRect(ox + x * k + k / 3, oy + 7 * k, Math.max(1, k / 3), 3 * k); }
  const ob = objective()[1], T = ob && THINGS.find(o => o.id === ob); if (T && Math.sin(t / 200) > -0.3) { g.fillStyle = P.amber; g.beginPath(); g.arc(ox + (T.x + 0.5) * k, oy + (T.y + 0.5) * k, k * 0.9, 0, TAU); g.fill(); }
  g.fillStyle = '#fff'; g.beginPath(); g.arc(ox + S.x * k, oy + S.y * k, Math.max(2, k * 0.7), 0, TAU); g.fill();
}
function render(t) {
  g.setTransform(DPR, 0, 0, DPR, 0, 0); g.fillStyle = '#0a0f1a'; g.fillRect(0, 0, VW, VH);
  const mw = MW * TS, mh = MH * TS; camX = mw <= VW ? (mw - VW) / 2 : clamp(S.x * TS - VW / 2, 0, mw - VW); camY = mh <= VH ? (mh - VH) / 2 : clamp(S.y * TS - VH / 2, 0, mh - VH);
  const x0 = Math.max(0, Math.floor(camX / TS)), x1 = Math.min(MW - 1, Math.ceil((camX + VW) / TS)), y0 = Math.max(0, Math.floor(camY / TS)), y1 = Math.min(MH - 1, Math.ceil((camY + VH) / TS));
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) drawTile(TILE[y][x], x, y, Math.round(x * TS - camX), Math.round(y * TS - camY), t);
  const near = MODE === 'play' ? nearest() : null;
  for (const o of THINGS) { if (o.x < x0 - 1 || o.x > x1 + 1 || o.y < y0 - 1 || o.y > y1 + 1 || !thingSeen(o)) continue; const px = Math.round(o.x * TS - camX), py = Math.round(o.y * TS - camY); drawThing(o, px, py, t);
    if (usable(o) && o.kind !== 'holo') { const todo = o.note ? !S.read[o.id] : o.kind === 'chest' ? !S.ended : !S.solved[o.puzzle || o.id]; if (todo || o === near) { const by = py - TS * 0.28 + Math.sin(t / 250 + o.x) * 3; g.fillStyle = o === near ? '#fff' : o.note ? '#f3ecd8' : P.amber; g.beginPath(); g.arc(px + TS / 2, by, TS * 0.2, 0, TAU); g.fill(); g.fillStyle = '#0b1220'; g.font = '800 ' + Math.round(TS * 0.3) + 'px system-ui'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(o === near ? 'E' : o.note ? '?' : '!', px + TS / 2, by + 1); g.textBaseline = 'alphabetic'; } } }
  if (lasersOn() && S.seen.corr) for (const x of LASERS) { const px = x * TS - camX + TS / 2, a = 0.65 + 0.3 * Math.sin(t / 90 + x); g.strokeStyle = 'rgba(255,60,80,' + a + ')'; g.lineWidth = 3; g.shadowColor = '#ff3050'; g.shadowBlur = 14; g.beginPath(); g.moveTo(px, 7 * TS - camY); g.lineTo(px, 10 * TS - camY); g.stroke(); g.shadowBlur = 0; g.fillStyle = '#20263a'; g.fillRect(px - 4, 7 * TS - camY - 2, 8, 6); g.fillRect(px - 4, 10 * TS - camY - 4, 8, 6); }
  if (PL.path && PL.path.length) { const e = PL.path[PL.path.length - 1]; g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 2; g.beginPath(); g.arc(e[0] * TS - camX, e[1] * TS - camY, TS * 0.2 + Math.sin(t / 150) * 2, 0, TAU); g.stroke(); }
  if (S.ended) drawCat(CAT.x * TS - camX, CAT.y * TS - camY, t);
  drawPlayer(S.x * TS - camX, S.y * TS - camY, t);
  const R = roomAt(Math.floor(S.x), Math.floor(S.y)), ppx = S.x * TS - camX, ppy = S.y * TS - camY, rad = Math.max(VW, VH), gr = g.createRadialGradient(ppx, ppy, TS * 2.2, ppx, ppy, rad * 0.75);
  gr.addColorStop(0, 'rgba(6,9,18,0)'); gr.addColorStop(1, R && R.out ? 'rgba(6,9,18,.5)' : 'rgba(6,9,18,.78)'); g.fillStyle = gr; g.fillRect(0, 0, VW, VH);
  if (R) { g.font = '700 13px system-ui'; g.textAlign = 'center'; g.fillStyle = 'rgba(11,18,32,.75)'; const w = g.measureText(R.name.toUpperCase()).width + 20; rr(VW / 2 - w / 2, VH - 30, w, 22, 8); g.fill(); g.fillStyle = '#e8eefc'; g.fillText(R.name.toUpperCase(), VW / 2, VH - 14); }
  drawMini(t);
  const a = $('act'); if (near && MODE === 'play') { a.style.display = 'block'; a.textContent = near.note ? 'Read (E)' : near.kind === 'chest' ? 'Open (E)' : near.kind === 'holo' ? 'Look (E)' : 'Examine (E)'; } else a.style.display = 'none';
  $('objt').textContent = objective()[0];
}

/* ===== MAIN ===== */
let lastT = 0;
function frame(t) {
  const dt = Math.min(0.05, (t - lastT) / 1000); lastT = t;
  const c = DLG.cur; if (c && DLG.n < c.text.length && t - DLG.last >= 22) { DLG.n = Math.min(c.text.length, DLG.n + Math.max(1, Math.floor((t - DLG.last) / 22))); DLG.last = t; if (/\S/.test(c.text[DLG.n - 1] || '')) SFX.type(c.who); paintLine(); }
  update(dt); updateCat(dt); if (MODE !== 'puzzle') render(t);
  for (const fn of G.loops.slice()) { try { fn(t); } catch (e) { console.error(e); } }
  requestAnimationFrame(frame);
}
function init() {
  if (!PREVIEW) load(); resize(); window.addEventListener('resize', resize);
  window.addEventListener('keydown', e => { const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (e.key === 'Escape') { if ($('modal').style.display === 'flex') closeModal(); return; }
    if ($('modal').style.display === 'flex' || MODE === 'puzzle') return;
    if (MODE === 'talk') { if (k === ' ' || k === 'Enter' || k === 'e') { e.preventDefault(); advance(); } return; }
    if (k === 'e' || k === ' ' || k === 'Enter') { e.preventDefault(); const o = nearest(); if (o) interact(o); return; }
    if (k.startsWith('Arrow') || 'wasd'.includes(k)) { keys[k] = true; if (k.startsWith('Arrow')) e.preventDefault(); } });
  window.addEventListener('keyup', e => { const k = e.key.length === 1 ? e.key.toLowerCase() : e.key; keys[k] = false; });
  window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
  cv.addEventListener('pointerdown', e => { if (MODE === 'talk') return advance(); if (MODE !== 'play') return; const r = cv.getBoundingClientRect(), tx = Math.floor((e.clientX - r.left + camX) / TS), ty = Math.floor((e.clientY - r.top + camY) / TS); if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) return; goTo(tx, ty); });
  $('dlg').onclick = advance; $('dlg').onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); advance(); } };
  $('act').onclick = () => { const o = nearest(); if (o) interact(o); };
  $('bNote').onclick = notebook; $('bMenu').onclick = menu;
  $('bMute').onclick = () => { S.mute = !S.mute; save(); $('bMute').textContent = (S.mute ? 'Muted' : 'Sound'); }; $('bMute').textContent = (S.mute ? 'Muted' : 'Sound');
  $('puz').addEventListener('pointerdown', e => { if (e.target.closest('button, .gcard, select, .digit')) SFX.click(); });
  $('bLeave').onclick = () => closePuzzle(false);
  $('bRetry').onclick = () => { G.tries++; runStep(G.i); };
  $('bNext').onclick = () => { if (G.i + 1 < G.def.steps.length) runStep(G.i + 1); else { S.step[G.id] = 0; closePuzzle(true); } };
  $('bHint').onclick = () => { const h = G.s && G.s.hints; if (!h) return; if (G.hint < h.length) G.hint++; $('hint').innerHTML = ''; h.slice(0, G.hint).forEach((t, k) => $('hint').append(el('div', {}, el('b', {}, ['Nudge: ', 'Method: ', 'Walkthrough: '][k]), t))); $('bHint').textContent = G.hint < h.length ? 'Another hint (' + G.hint + ' of ' + h.length + ')' : 'All hints shown'; };
  $('modal').onclick = e => { if (e.target === $('modal') && MODE !== 'title') closeModal(); };
  requestAnimationFrame(frame); title();
}
init();

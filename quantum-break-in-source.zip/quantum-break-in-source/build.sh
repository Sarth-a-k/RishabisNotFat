#!/bin/sh
cd /home/claude/qb
(cat head.html; for f in sim widgets comp1 comp2 comp3 data game; do if [ $f = sim ]; then cat $f.js; else grep -v "^'use strict';$" $f.js; fi; echo; done; printf '</script>\n</body>\n</html>\n') > index.html
sed "s/PREVIEW = false;/PREVIEW = true;/" index.html > preview.html
python3 -c "
s=open('index.html').read();open('all.js','w').write(s[s.index('<script>')+8:s.rindex('</script>')])"
node --check all.js && wc -c index.html preview.html && grep -c "PREVIEW = true" preview.html

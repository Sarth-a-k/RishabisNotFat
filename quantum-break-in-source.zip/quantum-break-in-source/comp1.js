
/* ===== COMPONENTS: step players (one per puzzle type, driven by level data) ===== */
const COMP = {};
const lookBtns = (fn, ns) => row(...(ns || CONFIG.looks).map(n => btn('Look ×' + n, () => fn(n))));
const MAT = { X: '[0 1; 1 0]', Z: '[1 0; 0 −1]', H: '[1 1; 1 −1]/√2' };

/* Level 0.1: a bit versus a spinning coin */
COMP.coin = (st, tl, s, ctx) => {
  let tilt = 0.5, bit = 0, land = null, landT = -1e9; const hist = HistW(['0', '1']), c = mkCanvas(440, 150), val = el('b', {}, '50%');
  ctx.loop(t => { const x = c.x; x.clearRect(0, 0, 440, 150); x.textAlign = 'center'; x.font = '13px system-ui';
    x.fillStyle = P.dim; x.fillText('a bit: one face up', 110, 16); x.fillText('a qubit: spinning, both at once', 330, 16);
    x.beginPath(); x.arc(110, 80, 42, 0, TAU); x.fillStyle = bit ? P.amber : '#efe6ff'; x.fill(); x.fillStyle = '#0d0716'; x.font = '700 30px system-ui'; x.fillText(bit, 110, 91);
    const shown = t - landT < 900 && land != null, wd = shown ? 42 : 42 * Math.abs(Math.cos(t / 130));
    x.beginPath(); x.ellipse(330, 80, Math.max(wd, 2), 42, 0, 0, TAU); x.fillStyle = shown ? (land ? P.amber : '#efe6ff') : (Math.cos(t / 130) > 0 ? '#bfe9f1' : '#f4d9a8'); x.fill(); x.strokeStyle = P.cyan; x.lineWidth = 2; x.stroke();
    x.fillStyle = '#0d0716'; x.font = '700 ' + (shown ? 30 : 15) + 'px system-ui'; x.fillText(shown ? land : 'both', 330, shown ? 91 : 85); });
  const look = n => { for (let i = 0; i < n; i++) { const b = new State(1).fromBloch(0, 2 * Math.asin(Math.sqrt(tilt)), 0).measure(0, ctx.rng); hist.add(b); land = b; } landT = performance.now(); hist.draw(); ctx.move();
    ctx.math('amplitudes: ' + Math.sqrt(1 - tilt).toFixed(3) + ' |0⟩ + ' + Math.sqrt(tilt).toFixed(3) + ' |1⟩ · P(1) = ' + tilt.toFixed(2));
    if (Math.abs(tilt - 0.8) <= 0.05 && hist.total >= 50 && Math.abs(hist.frac(1) - 0.8) <= 0.12) ctx.solve(); else if (hist.total >= 50) ctx.fb(Math.abs(tilt - 0.8) > 0.05 ? 'Plenty of looks. Now tilt the coin toward 80% and look again.' : 'Close. Look a few more times.'); };
  st.append(card(null, c, row(btn('Flip the bit', () => { bit ^= 1; })), el('label', {}, 'Tilt: chance of landing on 1 ', el('input', { type: 'range', min: 0, max: 100, value: 50, oninput: e => { tilt = e.target.value / 100; val.textContent = e.target.value + '%'; hist.clear(); land = null; } }), val), lookBtns(look, [1, 20, 100])), card('Results of your looks', hist.el, btn('Clear', () => hist.clear(), 'sm')));
};
/* Level 0.2: amplitudes, squares are the odds */
COMP.amps = (st, tl, s, ctx) => {
  let a = 1, b = 0, task = 0; const stored = [], bars = BarsW({ labels: ['|0⟩', '|1⟩'], vals: [1, 0], w: 240, h: 190, onDrag: (i, v, end) => { if (end) { ctx.move(); return check(); } if (i === 0) { a = v; b = (b < 0 ? -1 : 1) * Math.sqrt(1 - a * a); } else { b = v; a = (a < 0 ? -1 : 1) * Math.sqrt(1 - b * b); } upd(); } });
  const info = el('div', { cls: 'note' }), extra = el('div', { cls: 'col' }), T = ['Make the odds 75% for 0 and 25% for 1.', 'Make the odds 100% for 0 and 0% for 1.', 'Build two different qubits that are both 50/50: one with two plus signs, one with a plus and a minus. Store each, then look at both.'];
  const upd = () => { bars.set([a, b]); info.innerHTML = 'Odds: <b>' + pct(a * a) + '</b> for 0, <b>' + pct(b * b) + '</b> for 1. Amplitudes are the raw ingredients; the odds are their squares.'; ctx.math('α = ' + a.toFixed(3) + ', β = ' + b.toFixed(3) + ' · α² + β² = ' + (a * a + b * b).toFixed(3)); };
  const check = () => { if ((task === 0 && Math.abs(a * a - 0.75) < 0.05) || (task === 1 && a * a > 0.99)) { task++; ctx.fb('Done. Next task.', true); ctx.task(T[task]); if (task === 2) stage3(); } };
  function stage3() { const hs = [HistW(['0', '1'], { w: 150, h: 100 }), HistW(['0', '1'], { w: 150, h: 100 })], lab = el('div', { cls: 'note' }, 'Stored: none yet.');
    extra.append(row(btn('Store this qubit', () => { if (Math.abs(Math.abs(a) - SQ) > 0.06) return ctx.fb('That one is not 50/50 yet. Drag a bar to about 0.71.'); const sg = a * b >= 0 ? 1 : -1; if (stored.includes(sg)) return ctx.fb('You already stored that one. Flip one bar below the line to make the other qubit.'); stored.push(sg); lab.textContent = 'Stored: ' + stored.map(x => x > 0 ? '(+0.71, +0.71)' : '(+0.71, −0.71)').join(' and '); ctx.fb('Stored.', true); }),
      btn('Look ×100 at both', () => { if (stored.length < 2) return ctx.fb('Store both qubits first.'); stored.forEach((sg, k) => { hs[k].clear(); for (let i = 0; i < 100; i++) hs[k].add(new State(1).fromBloch(0, Math.PI / 2, sg > 0 ? 0 : Math.PI).measure(0, ctx.rng)); hs[k].draw(); }); ctx.say('Same odds, different qubits. The minus sign is hidden when you look, but remember it.', 'happy'); ctx.solve(); })), lab, row(card('plus, plus', hs[0].el), card('plus, minus', hs[1].el))); }
  st.append(row(card('Drag the bars', bars.el, info), extra)); ctx.task(T[0]); upd();
};
/* Level 0.3 and 0.4: shuffle pipelines (classical vs quantum, and the camera in the middle) */
COMP.pipe = (st, tl, s, ctx) => {
  const peek = s.mode === 'peek', done = new Set(); let cam = false, show = false;
  const hc = HistW(['0', '1'], { w: 170, h: 110 }), hq = HistW(['0', '1'], { w: 170, h: 110 }), pc = mkCanvas(380, 170), box = t => el('span', { cls: 'pbox' }, t);
  const runQ = () => { hq.clear(); for (let i = 0; i < 100; i++) { const q = new State(1).apply1('H', 0); if (cam) q.measure(0, ctx.rng); hq.add(q.apply1('H', 0).measure(0, ctx.rng)); } hq.draw(); ctx.move();
    done.add(peek ? (cam ? 'on' : 'off') : 'q'); if (peek) ctx.fb(cam ? 'Camera on: the middle look forced a choice, so the result is 50/50.' : 'Camera off: always 0.', true); fin(); };
  const runC = () => { hc.clear(); for (let i = 0; i < 100; i++) { let b = 0; b = ctx.rng() < 0.5 ? 0 : 1; b = ctx.rng() < 0.5 ? 0 : 1; hc.add(b); } hc.draw(); done.add('c'); fin(); };
  const fin = () => { if (peek ? done.has('on') && done.has('off') : done.has('q') && done.has('c')) ctx.solve(); };
  const paths = t => { const x = pc.x, k = show ? Math.min(3, Math.floor(t / (ctx.dur() * 1.6)) % 5) : -1; x.clearRect(0, 0, 380, 170); if (!show) return; x.font = '12px system-ui'; x.textAlign = 'center';
    const node = (X, Y, t2, col) => { x.fillStyle = col || '#24123a'; x.beginPath(); x.arc(X, Y, 15, 0, TAU); x.fill(); x.fillStyle = '#fff'; x.fillText(t2, X, Y + 4); }, arr = (x1, y1, x2, y2, lab, neg) => { x.strokeStyle = neg ? P.neg : P.cyan; x.lineWidth = 2; x.beginPath(); x.moveTo(x1 + 16, y1); x.lineTo(x2 - 16, y2); x.stroke(); x.fillStyle = neg ? P.neg : P.cyan; x.fillText(lab, (x1 + x2) / 2, (y1 + y2) / 2 - 6); };
    node(40, 85, '0'); if (k >= 1) { arr(40, 85, 170, 40, '+0.71'); arr(40, 85, 170, 130, '+0.71'); node(170, 40, '0'); node(170, 130, '1'); }
    if (k >= 2) { arr(170, 40, 310, 40, '+½'); arr(170, 130, 310, 40, '+½'); arr(170, 40, 310, 130, '+½'); arr(170, 130, 310, 130, '−½ (minus)', true); node(310, 40, '0', P.good); node(310, 130, '1', P.bad); }
    if (k >= 3) { x.fillStyle = P.good; x.textAlign = 'left'; x.fillText('add: 100%', 330, 22); x.fillStyle = P.bad; x.fillText('cancel: 0%', 322, 160); } };
  ctx.loop(paths);
  if (peek) st.append(card('Quantum pipeline with a camera slot', row(box('Start 0'), '→', box('H'), '→', btn('Camera: off', e => { cam = !cam; e.target.textContent = 'Camera: ' + (cam ? 'ON (looks in the middle)' : 'off'); e.target.classList.toggle('on', cam); }), '→', box('H'), '→', btn('Look ×100', runQ, 'pri')), hq.el));
  else st.append(row(card('Classical shuffler', row(box('Start 0'), '→', box('Randomize'), '→', box('Randomize'), '→', btn('Look ×100', runC, 'pri')), hc.el), card('Quantum shuffler (the H gate)', row(box('Start 0'), '→', box('H'), '→', box('H'), '→', btn('Look ×100', runQ, 'pri')), hq.el)),
    card('Why? Follow the amplitudes', btn('Show paths', e => { show = !show; e.target.classList.toggle('on', show); }), pc));
  if (peek) ctx.task('Run it with the camera off (always 0), then with the camera on (50/50).');
};
/* Level 0.5: n qubits hold 2^n amplitudes */
COMP.ncoins = (st, tl, s, ctx) => {
  let n = 1; const bars = BarsW({ w: 560, h: 170 }), out = el('div', { cls: 'big' }, ' '), info = el('div', { cls: 'note' });
  const upd = () => { const N = 1 << n; bars.set(Array(N).fill(1 / Math.sqrt(N)), Array.from({ length: N }, (_, i) => i.toString(2).padStart(n, '0'))); info.innerHTML = '<b>' + n + '</b> qubit' + (n > 1 ? 's' : '') + ' → <b>' + N + '</b> amplitudes, each ' + (1 / Math.sqrt(N)).toFixed(3) + ', so each answer has a ' + (100 / N).toFixed(1) + '% chance.'; };
  st.append(card('Give every qubit an H', el('label', {}, 'Qubits: ', el('input', { type: 'range', min: 1, max: 5, value: 1, oninput: e => { n = +e.target.value; upd(); } })), bars.el, info,
    row(btn('Look', () => { const q = new State(n); let r = ''; for (let i = 0; i < n; i++) q.apply1('H', i); for (let i = 0; i < n; i++) r += q.measure(i, ctx.rng); out.textContent = 'You saw: ' + r; if (n >= 3) ctx.solve(); else ctx.fb('One answer only. Try it with 3 or more qubits.'); }, 'pri'), out)));
  ctx.task('Slide to 3 or more qubits, then Look.'); upd();
};
/* Level 1: Bloch sphere puzzles (regions, cameras, targets) driven by a task list */
COMP.sphere = (st, tl, s, ctx) => {
  let tasks = s.tasks, ti = 0;
  if (s.boss) { const r = ctx.rng, g = () => [30 + r() * 120, r() * 360]; tasks = [{ target: r() < 0.5 ? [0, 0] : [180, 0] }, { target: [90, r.int(8) * 45] }, { target: g() }, { target: g() }].map((t, i) => ({ text: 'Compass Lock ' + (i + 1) + ' of 4: match the amber ring.', target: t.target })); }
  const read = el('div', { cls: 'note' }), hist = HistW(['safe', 'caught'], { w: 170, h: 100, cols: [P.good, P.bad] });
  const pc = { z: v => (1 - v[2]) / 2, x: v => (1 + v[0]) / 2, y: v => (1 + v[1]) / 2 }, nm = { z: 'Up/down camera (detects 1)', x: 'Sideways X camera (detects +)', y: 'Sideways Y camera (detects +)' };
  const ok = (v, t) => t.region ? (t.region === 'north' ? v[2] > 0.93 : t.region === 'south' ? v[2] < -0.93 : Math.abs(v[2]) < 0.12) : t.cams ? Object.keys(t.cams).every(k => pc[k](v) <= t.cams[k] + 1e-9) : fidB(v, tv(t)) >= CONFIG.tol.fid1;
  const tv = t => vecOf(t.target[0] * Math.PI / 180, t.target[1] * Math.PI / 180);
  const B = BlochW({ snaps: true, onPick: (v, end) => { upd(); if (end && tasks[ti]) { ctx.move(); if (ok(v, tasks[ti])) { ctx.fb('Door open.', true); ti++; if (ti >= tasks.length) return ctx.solve(); setTask(); } } } });
  const upd = () => { const v = B.v, t = tasks[ti] || {}, a = angOf(v); let h = 'P(0) = <b>' + pct((1 + v[2]) / 2) + '</b> · P(1) = <b>' + pct((1 - v[2]) / 2) + '</b>';
    if (t.cams) for (const k in t.cams) { const p = pc[k](v), g = p <= t.cams[k] + 1e-9; h += '<br>' + (g ? '✓' : '✗') + ' ' + nm[k] + ': caught <b class="' + (g ? 'good' : 'bad') + '">' + pct(p) + '</b> (limit ' + pct(t.cams[k]) + ')'; }
    if (t.target) h += '<br>Match with the amber ring: <b>' + (fidB(v, tv(t)) * 100).toFixed(1) + '%</b> (need 98%)';
    read.innerHTML = h; ctx.math('a = ' + Math.cos(a[0] / 2).toFixed(3) + ' · b = ' + Math.sin(a[0] / 2).toFixed(3) + ' · e^{i·' + Math.round(a[1] * 180 / Math.PI) + '°} · (x, y, z) = (' + v.map(q => q.toFixed(2)).join(', ') + ')'); };
  const setTask = () => { const t = tasks[ti]; B.tgt = t.target ? tv(t) : null; B.shade = null; B.draw(); ctx.task(t.text); upd(); };
  const cross = () => { const t = tasks[ti] || tasks[tasks.length - 1]; if (!t.cams) return ctx.fb('No camera in this task.'); hist.clear(); const a = angOf(B.v);
    for (let i = 0; i < 20; i++) { let caught = false; for (const k in t.cams) { const q = new State(1).fromBloch(0, a[0], a[1]); if (k === 'x') q.apply1('H', 0); if (k === 'y') q.phase(0, -Math.PI / 2).apply1('H', 0); const m = q.measure(0, ctx.rng); if (k === 'z' ? m === 1 : m === 0) caught = true; } hist.add(caught ? 1 : 0); } hist.draw(); };
  st.append(row(card(null, B.el, el('div', { cls: 'tiny' }, 'Drag the dot. Drag past the rim to reach the far side, or rotate the view.')), col(card('Laser readout', read), s.cams ? card('Try 20 real crossings', row(btn('Run 20 crossings', cross), btn('Show safe zone', e => { const t = tasks[ti] || tasks[tasks.length - 1]; B.shade = B.shade ? null : (v => ok(v, t)); B.draw(); })), hist.el) : null)));
  setTask();
};
/* Level 2 part A: gate lab */
COMP.gatelab = (st, tl, s, ctx) => {
  const B = BlochW({ view: true }), bars = BarsW({ labels: ['|0⟩', '|1⟩'], w: 200, h: 150 }), tried = new Set(), log = [], desc = el('div', { cls: 'note' }), probs = el('div', { cls: 'note' });
  const D = { X: '<b>X, "Flip".</b> Swaps |0⟩ and |1⟩ (north and south): a half-turn around the x-axis. It leaves |+⟩ unchanged.', Z: '<b>Z, "Phase flip".</b> Leaves |0⟩ and |1⟩ alone but flips the sign of the |1⟩ part: a half-turn around the vertical axis. An up/down camera sees no change, but it turns |+⟩ into |−⟩.', H: '<b>H, "Mixer".</b> Turns |0⟩ into |+⟩ and |1⟩ into |−⟩, and back again. It swaps the vertical axis with the sideways x-axis. H is the gate that creates superposition.' };
  const upd = () => { const q = stateOfVec(B.v), k = nameOf(B.v); const amp = k === '0' ? [1, 0] : k === '1' ? [0, 1] : k === '+' ? [SQ, SQ] : [SQ, -SQ]; bars.set(amp); probs.innerHTML = 'Now at <b>' + KET[k] + '</b> · P(0) = ' + pct(1 - q.prob(0)) + ' · P(1) = ' + pct(q.prob(0)); };
  const go = g => { B.anim(g, ctx.dur(), () => { B.v = NAMED[nameOf(B.v)].slice(); upd(); }); log.push(g); tried.add(g); desc.innerHTML = D[g] + '<br>All three gates undo themselves when applied twice.'; ctx.math('matrix of ' + g + ' = ' + MAT[g]); if (tried.size === 3) ctx.solve(); };
  st.append(row(card(null, B.el), col(card('Start state', row(...['0', '1', '+', '-'].map(k => btn(KET[k], () => { B.set(NAMED[k].slice()); log.length = 0; upd(); })))), card('Apply a gate', row(btn('X', () => go('X'), 'gate'), btn('Z', () => go('Z'), 'gate'), btn('H', () => go('H'), 'gate'), btn('Rewind', () => { const g = log.pop(); if (g) B.anim(g, ctx.dur(), () => { B.v = NAMED[nameOf(B.v)].slice(); upd(); }); else ctx.fb('Nothing to rewind.'); })), desc), card('Amplitudes', bars.el, probs))));
  ctx.task('Try each of X, Z and H on a few start states.'); upd();
};
COMP.gatetable = (st, tl, s, ctx) => {
  let left = 12; const t = el('table', { cls: 'tbl' }), ks = ['0', '1', '+', '-'];
  t.append(el('tr', {}, el('th', {}, 'gate \\ start'), ...ks.map(k => el('th', {}, KET[k]))));
  for (const g of ['X', 'Z', 'H']) t.append(el('tr', {}, el('th', {}, g), ...ks.map(k => { const want = nameOf(runGates(k, [g])), sel = el('select', { onchange: e => { ctx.move(); if (e.target.value === want) { e.target.disabled = true; e.target.className = 'okc'; if (--left === 0) ctx.solve(); } else { e.target.className = 'noc'; ctx.fb(g + ' on ' + KET[k] + ' is not ' + KET[e.target.value] + '. Picture the half-turn on the sphere.'); } } }, el('option', { value: '' }, '?'), ...ks.map(o => el('option', { value: o }, KET[o]))); return el('td', {}, sel); })));
  st.append(card('What does each gate do to each state?', t)); ctx.task('Fill in all 12 cells.');
};
/* Level 2 part B: vault doors on the circuit board */
COMP.circuit = (st, tl, s, ctx) => {
  let start = s.start, stage = 0, used = 0, round = 0, busy = false, logTxt = el('div', { cls: 'note' });
  const chain = s.chain, rounds = s.logs || 0, target = () => chain ? chain[stage] : s.target, info = el('div', { cls: 'note' });
  const B = BlochW({}), cards = Object.keys(s.inv).map(g => [g, 0]), inv = {}; for (const g in s.inv) if (s.inv[g] < 90) inv[g + '0'] = s.inv[g];
  const cur = () => runGates(start, W.ops.map(o => o[0]));
  const W = CircuitW({ cards, inv, slots: s.slots || 6, onMsg: m => ctx.fb(m), onChange: (k, op) => { if (k === 'add' && !busy) { busy = true; B.anim(op[0], ctx.dur(), () => { busy = false; show(); }); ctx.math('matrix of ' + op[0] + ' = ' + MAT[op[0]]); } else show(); } });
  const show = () => { B.v = cur(); B.ghosts = [{ v: NAMED[start], t: 'start' }]; B.tgt = NAMED[target()]; B.draw(); info.innerHTML = 'Start <b>' + KET[start] + '</b> → target <b>' + KET[target()] + '</b> · now at <b>' + (KET[nameOf(B.v)] || '?') + '</b>' + (s.par ? ' · par ' + s.par + ' gate' + (s.par > 1 ? 's' : '') : ''); };
  const newLog = () => { let seq, end; do { seq = Array.from({ length: 4 + ctx.rng.int(2) }, () => 'XZH'[ctx.rng.int(3)]); end = nameOf(runGates('0', seq)); } while (end === '0'); start = end; logTxt.innerHTML = 'The professor locked the door by running <b>' + seq.join(' → ') + '</b> on |0⟩. Lock ' + (round + 1) + ' of ' + rounds + '.'; ctx.addPar(seq.length); W.reset(); show(); };
  const run = () => { if (busy) return; busy = true; const ops = W.ops.slice(); B.v = NAMED[start].slice(); B.draw(); let i = 0;
    const nx = () => { if (i < ops.length) { W.draw(i); B.anim(ops[i++][0], ctx.dur(), nx); } else { W.draw(); busy = false; B.v = cur(); if (fidB(B.v, NAMED[target()]) >= CONFIG.tol.fid) win(); else ctx.fb(s.cant ? 'Not there. Is it even possible with these cards?' : 'The door stays shut: the qubit ended at ' + (KET[nameOf(B.v)] || 'another state') + '.'); } }; nx(); };
  const win = () => { used += W.ops.length; ctx.stat('gates', W.ops.length);
    if (chain && stage < chain.length - 1) { start = chain[stage]; stage++; W.reset(true); show(); ctx.fb('Stage ' + stage + ' open. The next stage starts where you are.', true); ctx.task('Combo Lock stage ' + (stage + 1) + ' of ' + chain.length + '.'); return; }
    if (rounds && ++round < rounds) { ctx.fb('Unlocked. To undo a circuit, run it backwards.', true); return newLog(); }
    ctx.move(used); ctx.solve(); };
  st.append(row(card(null, B.el), col(card(s.door || 'Vault door', info, logTxt, W.el, row(btn('Run', run, 'pri'), btn('Step', () => { if (busy || !W.ops.length) return; W._k = ((W._k || 0) % W.ops.length) + 1; B.set(runGates(start, W.ops.slice(0, W._k).map(o => o[0]))); W.draw(W._k - 1); }), btn('Rewind', () => { if (busy || !W.ops.length) return; busy = true; let i = W.ops.length - 1; B.v = cur(); const nx = () => { if (i >= 0) { W.draw(i); B.anim(W.ops[i--][0], ctx.dur(), nx); } else { busy = false; W.draw(); ctx.fb('Rewound to the start. Every gate here undoes itself.', true); B.v = cur(); B.draw(); } }; nx(); }), btn('Reset', () => { if (!busy) { W.reset(); show(); } }),
    s.cant ? btn("It can't be done", () => { ctx.say('Right. X and Z only move a qubit between the poles or between |+⟩ and |−⟩. Only H can create a superposition from |0⟩.', 'happy'); ctx.solve(); }, 'warn') : null)))));
  if (rounds) newLog(); else show(); if (chain) ctx.task('Combo Lock stage 1 of ' + chain.length + '. Cards are shared across all stages.');
};

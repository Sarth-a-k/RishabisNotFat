/* ===== COMPONENTS, part 3: the redesigned vault dial (phase estimation) and glass relay (teleportation) ===== */
const sfx = k => { if (typeof SFX !== 'undefined' && SFX[k]) SFX[k](); };

/* The Resonance Dial. The code is a hidden angle. Pick how often the lock spins, cancel what you already know, then measure.
   Spin order and the counter-turn are the player's decisions; a sloppy probe gives a coin-flip digit. */
COMP.dial = (st, tl, s, ctx) => {
  const nd = s.digits, STEP = 22.5, c = mkCanvas(300, 300), tip = el('div', { cls: 'note' }), bat = el('div', { cls: 'row' }), reel = el('div', { cls: 'row' }), spins = el('div', { cls: 'row' }), cl = el('b', {}, '–'), lab = el('b', {}, '0°');
  let code, d, sure, k = null, fired = false, counter = 0, battery, strikes = 0, last = null, spinT = -1e9, spinM = 1, busy = false;
  const sld = el('input', { type: 'range', min: 0, max: 15, step: 1, value: 0, 'aria-label': 'Counter-turn', oninput: e => { counter = +e.target.value; lab.textContent = (counter * STEP) + '°'; upd(); } });
  const idx = kk => kk;                                                  // spinning 2^kk times exposes digit kk (0 = first); later digits add extra turn
  const ghosts = () => {                                                 // where the arrow would sit if the exposed digit were 0
    if (k == null) return []; const i = idx(k); let out = [0];
    for (let j = i + 1; j < nd; j++) { const a = 360 / Math.pow(2, j - i + 1); out = d[j] == null ? out.flatMap(g => [g, g + a]) : out.map(g => g + d[j] * a); }
    return out.map(g => ((g % 360) + 360) % 360);
  };
  const clarity = () => { const g = ghosts(); if (g.length !== 1) return null; const a = (g[0] - counter * STEP) * Math.PI / 180; return Math.cos(a / 2) ** 2; };
  const draw = t => {
    const x = c.x, R = 112, cx = 150, cy = 150; x.clearRect(0, 0, 300, 300);
    const e = clamp((t - spinT) / 800, 0, 1), rot = e < 1 ? (1 - Math.pow(1 - e, 3)) * spinM * TAU : 0;
    x.beginPath(); x.arc(cx, cy, R + 18, 0, TAU); x.fillStyle = '#0d0716'; x.fill(); x.strokeStyle = P.line; x.lineWidth = 2; x.stroke();
    for (let q = 0; q < 16; q++) { const a = q * TAU / 16 + rot; x.strokeStyle = q % 4 ? '#45285f' : P.dim; x.lineWidth = q % 4 ? 1 : 2.5; x.beginPath(); x.moveTo(cx + (R + 6) * Math.cos(a), cy - (R + 6) * Math.sin(a)); x.lineTo(cx + (R + 17) * Math.cos(a), cy - (R + 17) * Math.sin(a)); x.stroke(); }
    x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.fillStyle = '#150a24'; x.fill(); x.strokeStyle = '#6d4a94'; x.lineWidth = 1.5; x.stroke();
    x.font = '700 15px system-ui'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillStyle = P.good; x.fillText('0', cx + R - 16, cy); x.fillStyle = P.neg; x.fillText('1', cx - R + 16, cy);
    x.strokeStyle = 'rgba(255,255,255,.12)'; x.setLineDash([4, 6]); x.beginPath(); x.moveTo(cx - R + 30, cy); x.lineTo(cx + R - 30, cy); x.stroke(); x.setLineDash([]);
    const arrow = (deg, col, w, dash, len) => { const a = deg * Math.PI / 180, L = len || R - 34, ex = cx + L * Math.cos(a), ey = cy - L * Math.sin(a); x.strokeStyle = col; x.fillStyle = col; x.lineWidth = w; x.setLineDash(dash || []); x.beginPath(); x.moveTo(cx, cy); x.lineTo(ex, ey); x.stroke(); x.setLineDash([]); const b = Math.atan2(ey - cy, ex - cx); x.beginPath(); x.moveTo(ex, ey); x.lineTo(ex - 11 * Math.cos(b - 0.4), ey - 11 * Math.sin(b - 0.4)); x.lineTo(ex - 11 * Math.cos(b + 0.4), ey - 11 * Math.sin(b + 0.4)); x.fill(); };
    if (fired && e >= 1) { const g = ghosts(); g.forEach(a => arrow(a - counter * STEP, P.amber, g.length > 1 ? 1.5 : 2.5, [6, 5])); x.fillStyle = P.dim; x.font = '12px system-ui'; x.fillText(g.length > 1 ? g.length + ' possible ghosts: later digits unknown' : 'amber ghost = the part you already know', cx, cy + R - 20);
      const w = 0.5 + 0.5 * Math.sin(t / 160); x.fillStyle = 'rgba(94,246,255,' + (0.25 + 0.3 * w) + ')'; x.font = '800 30px system-ui'; x.fillText('?', cx, cy - 34); }
    else if (last && e >= 1) { arrow(last.bit ? 180 : 0, last.bit ? P.neg : P.good, 4); x.fillStyle = P.text; x.font = '12px system-ui'; x.fillText('measured: ' + last.bit, cx, cy + R - 20); }
    else if (e < 1) { x.fillStyle = P.cyan; x.font = '700 14px system-ui'; x.fillText('spinning ×' + spinM, cx, cy - 30); }
    x.beginPath(); x.arc(cx, cy, 7, 0, TAU); x.fillStyle = P.amber; x.fill(); x.textBaseline = 'alphabetic';
    c.dataset.ghost = fired && ghosts().length === 1 ? ghosts()[0] : '';
  };
  const upd = () => {
    bat.innerHTML = ''; bat.append(el('span', { cls: 'tiny' }, 'probe charges: '), ...Array.from({ length: s.battery }, (_, q) => el('span', { style: 'display:inline-block;width:16px;height:22px;border:1px solid ' + P.amber + ';background:' + (q < battery ? P.amber : 'transparent') })), el('span', { cls: 'tiny' }, strikes ? ' · wrong codes: ' + strikes : ''));
    reel.innerHTML = ''; reel.append(el('span', { cls: 'tiny' }, 'code: '), ...d.map((v, i) => el('span', { cls: 'digit' + (v == null ? '' : ' on'), title: v == null ? 'not read yet' : sure[i] ? 'certain' : 'coin flip', style: v != null && !sure[i] ? 'border-style:dashed;color:' + P.neg + ';border-color:' + P.neg : '' }, v == null ? '?' : v + (sure[i] ? '' : '?'))));
    spins.innerHTML = ''; for (let q = nd - 1; q >= 0; q--) spins.append(btn('Spin ×' + (1 << q), () => pick(q), q === k ? 'on' : ''));
    const cv = clarity(); cl.textContent = !fired ? '–' : cv == null ? 'unknown (coin flip)' : Math.round(cv * 100) + '%'; cl.style.color = !fired ? P.dim : cv != null && cv > 0.99 ? P.good : P.neg;
    fire.disabled = k == null || fired || busy; meas.disabled = !fired || busy; open.disabled = d.some(v => v == null) || fired; sld.disabled = !fired;
  };
  const pick = q => { if (fired || busy) return ctx.fb('Measure the probe you already fired first.'); k = q; last = null; upd(); tip.textContent = 'Spin ×' + (1 << q) + ' exposes digit ' + (idx(q) + 1) + ' of ' + nd + '. Fire the probe.'; };
  const fire = btn('Fire probe', () => { if (k == null || fired || busy) return; if (battery <= 0) return; battery--; ctx.fb(''); fired = true; busy = true; counter = 0; sld.value = 0; lab.textContent = '0°'; spinM = 1 << k; spinT = performance.now(); last = null; ctx.move(); sfx('whoosh'); upd();
    ctx.after(820, () => { busy = false; const g = ghosts(); sfx('click');
      tip.innerHTML = g.length > 1 ? 'The arrow could be in <b>' + g.length + ' places</b>, because you have not read the later digits yet. Measuring now is a coin flip. (Longest spin first is the trick.)' : Math.abs(g[0]) < 0.01 ? 'The ghost already points at 0. Nothing to cancel: <b>Measure</b>.' : 'The digits you already know have turned the arrow by <b>' + g[0] + '°</b>. Use the counter-turn to bring the amber ghost back to the right (0). Then the real arrow can only be right (0) or left (1).'; upd(); }); }, 'pri');
  const meas = btn('Measure', () => { if (!fired || busy) return; const i = idx(k), r = ipeProbe(code / (1 << nd), 1 << k, counter * STEP * Math.PI / 180, ctx.rng), ok = r.p1 < 0.001 || r.p1 > 0.999; d[i] = r.bit; sure[i] = ok; fired = false; last = { bit: r.bit }; sfx(ok ? 'unlock' : 'wrong');
    tip.innerHTML = ok ? 'Clean reading: digit ' + (i + 1) + ' is <b>' + r.bit + '</b>, for certain.' : 'Risky reading: the arrow was not lined up, so this <b>' + r.bit + '</b> was a ' + Math.round(Math.max(r.p1, 1 - r.p1) * 100) + '/' + Math.round(Math.min(r.p1, 1 - r.p1) * 100) + ' gamble. It is marked with a "?". You can probe that digit again.';
    k = null; if (battery <= 0 && (d.some(v => v == null))) return scramble('Out of charges before the code was complete.'); upd(); if (d.every(v => v != null)) tip.innerHTML += ' All digits read: press <b>Open</b>.'; });
  const open = btn('Open', () => { const val = parseInt(d.join(''), 2); if (val === code) { sfx('unlock'); tip.innerHTML = 'Code <b>' + d.join('') + '</b> accepted.'; open.disabled = true; return ctx.solve(); }
    strikes++; sfx('denied'); if (battery <= 0) return scramble('Wrong code and no charges left.'); ctx.fb('Wrong code. A digit marked "?" was a gamble that went wrong. Probe it again with the ghost lined up.'); upd(); }, 'pri');
  const scramble = why => { ctx.fb(why + ' The lock re-scrambles to a new code. Try again: longest spin first, line up the ghost every time.'); fresh(); };
  const fresh = () => { code = ctx.rng.int(1 << nd); if (nd > 2 && (code & 1) === 0 && ctx.rng() < 0.7) code |= 1; d = Array(nd).fill(null); sure = Array(nd).fill(false); k = null; fired = false; counter = 0; battery = s.battery; last = null; sld.value = 0; lab.textContent = '0°'; tip.innerHTML = 'Pick how many times the lock spins. Each spin count exposes a different digit of the code.'; upd(); };
  ctx.loop(draw);
  const right = col(card('1. Spin and fire', spins, row(fire)), card('2. Cancel what you know', el('label', { cls: 'col' }, el('span', {}, 'Counter-turn: ', lab), sld), el('div', { cls: 'note' }, 'Reading clarity: ', cl), row(meas)), card('3. The code', reel, row(open)), card(null, tip)); right.style.cssText = 'flex:1 1 300px;min-width:0'; st.append(row(card('The resonance dial', c, bat), right)); st.lastChild.style.alignItems = 'flex-start';
  fresh();
};

/* The Glass Relay. Teleport the crystal's state through one or more glass walls. Entangled links fade with time, the two
   bits take time to travel, and the fix must match the bits. Quality of the delivered state is the score. */
COMP.relay = (st, tl, s, ctx) => {
  const walls = s.walls, n = walls + 1, TAU_D = (s.tau || 45) * 1000, FLY = 2000, W = 620, H = 250, c = mkCanvas(W, H), info = el('div', { cls: 'note' }), gapRow = el('div', { cls: 'row' }), fixBox = el('div', { cls: 'row' });
  const xs = Array.from({ length: n }, (_, i) => 60 + i * (W - 120) / (n - 1)), names = n === 2 ? ['CHAMBER', 'YOUR SOCKET'] : ['CHAMBER', 'RELAY A', 'RELAY B', 'YOUR SOCKET'];
  let holder, secret, q, links, flight, pend, tx, tz, done, puff = -1e9, runs = 0;
  const now = () => performance.now(), fresh = L => Math.exp(-(now() - L.born) / TAU_D);
  const reset = () => { holder = 0; secret = vecOf((ctx.rng() < 0.5 ? 0.55 : Math.PI - 1.15) + ctx.rng() * 0.6, ctx.rng() < 0.5 ? 0 : Math.PI);   /* kept in the picture plane so every fix is visible */ q = 1; links = Array(walls).fill(null); flight = null; pend = null; tx = tz = false; done = false; upd(); info.innerHTML = 'The crystal\'s state (cyan arrow) is in the chamber. Make an entangled link across the first wall.'; };
  const quality = () => (1 + q) / 2;
  const draw = t => {
    const x = c.x; x.clearRect(0, 0, W, H); x.font = '11px system-ui'; x.textAlign = 'center';
    for (let i = 0; i < walls; i++) { const wx = (xs[i] + xs[i + 1]) / 2; x.fillStyle = 'rgba(160,220,255,.10)'; x.fillRect(wx - 7, 18, 14, H - 70); x.strokeStyle = 'rgba(200,235,255,.5)'; x.lineWidth = 1; x.strokeRect(wx - 7, 18, 14, H - 70); x.fillStyle = P.dim; x.fillText('glass', wx, 14);
      const L = links[i]; if (L) { const f = fresh(L), y0 = 62; x.strokeStyle = 'rgba(255,61,139,' + (0.15 + 0.85 * f) + ')'; x.lineWidth = 1 + 3 * f; x.beginPath(); for (let u = 0; u <= 40; u++) { const X = xs[i] + 30 + (xs[i + 1] - xs[i] - 60) * u / 40, Y = y0 + Math.sin(u * 0.9 + t / 140) * 7 * (L.used ? 0.3 : 1); u ? x.lineTo(X, Y) : x.moveTo(X, Y); } x.stroke(); x.fillStyle = f > 0.85 ? P.good : f > 0.7 ? P.amber : P.bad; x.font = '700 12px system-ui'; x.fillText((L.used ? 'far half waiting: ' : 'link: ') + Math.round(f * 100) + '%', wx, 44); x.font = '11px system-ui'; }
      x.strokeStyle = P.dim; x.setLineDash([5, 5]); x.lineWidth = 1; x.beginPath(); x.moveTo(xs[i], H - 34); x.lineTo(xs[i + 1], H - 34); x.stroke(); x.setLineDash([]); if (i === 0) { x.fillStyle = P.dim; x.textAlign = 'left'; x.fillText('phone wire (ordinary bits)', xs[0] - 40, H - 14); x.textAlign = 'center'; } }
    xs.forEach((X, i) => { x.beginPath(); x.arc(X, 120, 34, 0, TAU); x.fillStyle = '#150a24'; x.fill(); x.strokeStyle = i === holder ? P.cyan : pend && pend.to === i ? P.amber : '#6d4a94'; x.lineWidth = i === holder ? 3 : 1.5; x.stroke(); x.fillStyle = P.dim; x.fillText(names[i], X, 174);
      if (i === holder && !flight) { const L = 26 * q; x.strokeStyle = P.cyan; x.lineWidth = 3; x.beginPath(); x.moveTo(X, 120); x.lineTo(X + secret[0] * L, 120 - secret[2] * L); x.stroke(); x.beginPath(); x.arc(X + secret[0] * L, 120 - secret[2] * L, 4, 0, TAU); x.fillStyle = P.cyan; x.fill(); }
      else if (pend && pend.to === i) { const v = pend.S.bloch(2), L = 26 * q; x.strokeStyle = P.amber; x.lineWidth = 2; x.setLineDash([4, 3]); x.beginPath(); x.moveTo(X, 120); x.lineTo(X + v[0] * L, 120 - v[2] * L); x.stroke(); x.setLineDash([]); x.fillStyle = P.amber; x.fillText('scrambled', X, 80); }
      else if (flight && flight.to === i) { x.fillStyle = P.dim; x.font = '700 18px system-ui'; x.fillText('?', X, 126); x.font = '11px system-ui'; }
      if (t - puff < 500 && i === (flight ? flight.from : -1)) { const e = (t - puff) / 500; x.strokeStyle = 'rgba(94,246,255,' + (1 - e) + ')'; x.lineWidth = 2; x.beginPath(); x.arc(X, 120, 10 + e * 34, 0, TAU); x.stroke(); } });
    if (flight) { const e = clamp((now() - flight.t0) / FLY, 0, 1), X = xs[flight.from] + (xs[flight.to] - xs[flight.from]) * e; [flight.m0, flight.m1].forEach((b, j) => { x.fillStyle = P.amber; x.fillRect(X - 20 + j * 22, H - 44, 18, 18); x.fillStyle = '#0d0716'; x.font = '700 12px system-ui'; x.fillText(b, X - 11 + j * 22, H - 31); }); x.font = '11px system-ui';
      if (e >= 1) { pend = { to: flight.to, S: flight.S, m0: flight.m0, m1: flight.m1, link: flight.link }; flight = null; tx = tz = false; sfx('pickup'); info.innerHTML = 'The bits arrived: <b>m0 = ' + pend.m0 + ', m1 = ' + pend.m1 + '</b>. Set the fix (m1 = 1 → X, m0 = 1 → Z) and apply it. The far half of the link keeps fading while you think.'; upd(); } }
    x.fillStyle = P.text; x.font = '700 13px system-ui'; x.textAlign = 'right'; x.fillText('signal quality: ' + Math.round(quality() * 100) + '%  (need ' + Math.round(s.need * 100) + '%)', W - 8, H - 8); x.textAlign = 'center';
  };
  const upd = () => {
    gapRow.innerHTML = ''; for (let i = 0; i < walls; i++) { const L = links[i]; gapRow.append(btn((L && !L.used ? 'Re-link ' : 'Link ') + (walls > 1 ? 'wall ' + (i + 1) : 'across the glass'), () => link(i), L && !L.used ? '' : (i === holder ? 'pri' : ''))); }
    const can = !done && !flight && !pend && holder < walls && links[holder] && !links[holder].used; bm.disabled = !can; bm.className = can ? 'pri' : '';
    fixBox.innerHTML = ''; if (pend) { fixBox.dataset.m0 = pend.m0; fixBox.dataset.m1 = pend.m1; fixBox.append(el('span', { cls: 'big' }, 'm0 = ' + pend.m0 + ' · m1 = ' + pend.m1), btn('X: ' + (tx ? 'ON' : 'off'), () => { tx = !tx; upd(); }, tx ? 'on' : ''), btn('Z: ' + (tz ? 'ON' : 'off'), () => { tz = !tz; upd(); }, tz ? 'on' : ''), btn('Apply fix', applyFix, 'pri')); }
    else { delete fixBox.dataset.m0; fixBox.append(el('span', { cls: 'tiny' }, done ? '' : flight ? 'Bits in transit…' : 'The fix controls appear here when the two bits arrive.')); }
    if (done && quality() < s.need) fixBox.append(btn('Run it again', () => { runs++; reset(); }, 'pri'));
  };
  const link = i => { if (done) return; const L = links[i]; if (L && L.used) return ctx.fb('That link is already in use.'); if (i < holder) return ctx.fb('The state is already past that wall.'); links[i] = { born: now(), used: false }; sfx('shimmer'); ctx.move();
    info.innerHTML = i === holder ? 'Linked: one entangled half on each side of the glass. It starts fading at once, so use it: <b>Measure here</b>.' : 'Linked wall ' + (i + 1) + ' early. It will keep fading until you get there.'; upd(); };
  const bm = btn('Measure here (Bell measurement)', () => { const L = links[holder]; if (done || flight || pend || !L || L.used) return; const S = tpBuild(secret); TP_OPS.forEach(op => applyOp(S, op)); const m0 = S.measure(0, ctx.rng), m1 = S.measure(1, ctx.rng); L.used = true; flight = { from: holder, to: holder + 1, t0: now(), S, m0, m1, link: L }; puff = now(); holder = -1; sfx('lid'); ctx.move();
    info.innerHTML = 'Measured. The original state is <b>gone</b> from this side (it cannot be copied). A scrambled version now sits beyond the glass, and the two bits that unscramble it are on the wire. Nothing useful arrives until they do.'; upd(); });
  const applyFix = () => { if (!pend) return; const T = pend.S.copy(); if (tx) T.apply1('X', 2); if (tz) T.apply1('Z', 2); ctx.move();
    if (fidB(T.bloch(2), secret) < 0.999) { sfx('denied'); return ctx.fb('Still scrambled. Read the bits again: m1 = 1 means X on, m0 = 1 means Z on. Otherwise leave it off.'); }
    q *= fresh(pend.link); holder = pend.to; links[holder - 1] = null; pend = null; sfx('unlock'); ctx.fb('State restored at ' + names[holder] + '.', true);
    if (holder === n - 1) { done = true; const F = quality(); if (F >= s.need) { info.innerHTML = 'Delivered at <b>' + Math.round(F * 100) + '%</b> quality. The socket accepts it.'; upd(); return ctx.solve(); }
      info.innerHTML = 'Delivered, but only at <b>' + Math.round(F * 100) + '%</b>. Too blurry for the socket. Links fade from the moment they are made: make each one just before you need it, and apply the fix quickly.'; sfx('denied'); }
    else info.innerHTML = 'One wall down. Link the next wall <b>now</b>, not earlier: a link made in advance would already have faded.'; upd(); };
  ctx.loop(draw);
  st.append(card('The glass relay', c, el('div', { cls: 'ct', style: 'font-size:13px' }, '1. Entangle'), gapRow, el('div', { cls: 'ct', style: 'font-size:13px' }, '2. Measure and send the bits'), row(bm), el('div', { cls: 'ct', style: 'font-size:13px' }, '3. Fix at the far side'), fixBox, info));
  reset();
};
